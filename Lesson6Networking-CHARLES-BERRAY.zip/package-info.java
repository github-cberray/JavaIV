package assignment6;

// NETWORKING

//Using the skills you have learned related to Network Programming in this lesson, 
//write TWO Java console applications, one named Lesson6NetworkingServer and the other named Lesson6NetworkingClient.

//- Lesson6NetworkingServer. --port NUMBER. When you start up the Lesson6NetworkingServer, 
//give it a port number to listen on. When a client connects to the server, send back the folllowing:

//-----------------------------------------------
//HTTP/1.0 200 OK
//Content-Type: text/html


//<html>
//<head><title>Java Networking</title></head>
//<body>
//<h1>Java Networking</h1>
//</html>
//-----------------------------------------------
//- Lesson6NetworkingClient --server ADDRESS --port PORT. After starting up the Lesson6NetworkingServer, 
//in another console window startup the Lesson6NetworkingClient, specifying the server address and port number. 
//Then connect to the server, and display the info returned by the server to the console.
//- Use your web-browser to also connect to the server. What do you observe?



//The server and client interact well.  I was able to connect the web browser to the page, and
// this was only clear from the accept showing on the server end.  On the client end (browser)
// the html did not render in the browser.  I suspect that if I'd handled it as a URL object
// then I would have had no issue.