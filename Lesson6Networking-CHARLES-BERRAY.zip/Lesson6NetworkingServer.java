package assignment6;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/*
 * Lesson6NetworkingServer - provides a server for a networking connection.
 *  Upon initial receipt of traffic, it replies with html content specified
 *  in file Lesson6NetworkingServerMessage.html.  After that, it monitors
 *  for a BYE message to terminate.
 * 
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.01.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 */
public class Lesson6NetworkingServer {

	//static ServerSocket variable
	private static ServerSocket server;
	//socket server port on which it will listen
	private static int NUMBER = 9876;
	private DataInputStream inFromSocket = null;
	private DataOutputStream outToSocket = null;

	/*
	 * Lesson6NetworkingServer - method to create, monitor, and respond to input from the user
	 *  - non-empty requests result in an html file data being sent to the user
	 *  - a request of 'BYE' results in the session being closed down
	 */
	public Lesson6NetworkingServer(int NUMBER) throws IOException {
		try {
			//Create connection to socket
			server = new ServerSocket(NUMBER);
			System.out.println("Waiting for the client request");

			//creating socket and waiting for client connection
			Socket socket = server.accept();
			System.out.println("Client accepted");

			//Convert html file to data ready for socket
			final String FILE_TO_SEND="Lesson6NetworkingServerMessage.html";
			File theFile=new File(FILE_TO_SEND);
			BufferedReader br = new BufferedReader(new FileReader(theFile));
			String st;
			String strOut="";
			byte[] bytes = new byte[60000];
			while((st=br.readLine())!=null) {
				strOut=strOut+"\n"+st;
			}
			bytes=strOut.getBytes(StandardCharsets.UTF_8);

			//Provide means of receiving data from socket and sending file data
			inFromSocket=new DataInputStream(new BufferedInputStream(socket.getInputStream()));
			outToSocket = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
			
			//MONITOR SOCKET INPUT
			
			String line="";
			Boolean done=false;
			while (!done&&!line.contains("BYE")) {
				try {//monitor line for traffic and print it to console
					line=inFromSocket.readUTF();
					if(!line.equals("")) {
						System.out.println("Received: \'" + line + "\' from client");
						// SEND HTML TO SOCKET
						outToSocket.write(bytes);//Send html bytes to the socket
						//System.out.println(strOut);//Show the html on the console
						System.out.println("HTML Message Sent from file \'Lesson6NetworkingServerMessage.html\'.");
						done=true;
					}
					if (line.equals("BYE")) {
					System.out.println("Closing down the session...");
					done=true;
					
				}
				} catch (IOException e) {
					//e.printStackTrace();
				} 
				outToSocket.close();//Close the data output stream
			}
			
			//CLOSE DOWN THE CONNECTION
			
			System.out.println("Shutting down Socket server. Goodbye!!");
			inFromSocket.close();
			br.close();
			server.close();
			socket.close();
			
		}catch(IOException e) {
			e.printStackTrace();
		}

	}

	/*
	 * main - method to initiate the server
	 */
	public static void main(String args[]) throws IOException, ClassNotFoundException{
		Lesson6NetworkingServer lns = new Lesson6NetworkingServer(NUMBER);
	}
	
}

