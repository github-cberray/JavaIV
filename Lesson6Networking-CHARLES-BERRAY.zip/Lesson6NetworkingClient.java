package assignment6;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/*
 * Lesson6NetworkingClient - provides a client side for a networking connection
 * 
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.01.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 */
public class Lesson6NetworkingClient {

	private static int NUMBER = 9876;
	private  Socket socket = null;
	private  DataInputStream inFromConsole = null;
	private DataInputStream inFromSocket = null;
	//private  BufferedReader inFromServer = null;
	private  DataOutputStream outToSocket = null;

	/*
	 * Lesson6NetworkingClient - method to implement a connection to a server on port 9876
	 */
	public Lesson6NetworkingClient(String ADDRESS, int NUMBER) throws IOException {
		
		try {	//Establish socket and connection	
			socket = new Socket(ADDRESS, NUMBER);
			System.out.println("Connected to Socket");

			//Provide resource to send information out to the socket
			outToSocket = new DataOutputStream(socket.getOutputStream());

			//Provide resource to receive information from the console
			inFromConsole = new DataInputStream(System.in);

			//Provide resource to receive data from the socket
			inFromSocket=new DataInputStream(new BufferedInputStream(socket.getInputStream()));

		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		//We monitor the console and send the message to the server
		Boolean done=false;
		String line="";
		while (!done&& !line.contains("BYE")) {
			try {//From the console to the socket
				line=inFromConsole.readLine();
				outToSocket.writeUTF(line);
				if (!line.equals("")) {
					done=true;
				}
			} catch (IOException e){
				e.printStackTrace();
			}
		}

		//We've sent our original message, now we await the html file
		done=false;
		while (!done&&!line.equals("BYE")) {
			try {//From the socket to the console
				line=new String(inFromSocket.readAllBytes(),StandardCharsets.UTF_8);
				System.out.println(line);
				done=true;
			} catch (IOException e){
				e.printStackTrace();
			}
		}

		try {//close things down
			inFromConsole.close();
			outToSocket.close();
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


public static void main(String[] args) throws UnknownHostException, IOException, ClassNotFoundException, InterruptedException{
	//get the localhost IP address, if server is running on some other IP, you need to use that
	InetAddress host = InetAddress.getLocalHost();
	final String ADDRESS = host.getHostName();

	Lesson6NetworkingClient client = new Lesson6NetworkingClient(ADDRESS, NUMBER);
}
} 