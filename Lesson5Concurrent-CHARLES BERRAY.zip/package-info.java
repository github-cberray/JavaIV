package assignment5;

//Java console application named Lesson5Concurrent that does the following:
   //- Accepts "--num-threads NUMBER-OF-THREADS" where you can specify how many threads to create. 
   //- Accepts "--ReentrantLock" if  you want to use locking. By default you do not use any locking
   //- Accepts "--AtomicLong" if you want to use AtomicLong. By default you do not use any locking.

//NOTE: You can either use no-locking (the default), --ReentrantLock, or --AtomicLong for a given test run.

//The program should start by creating the number of threads specified on the command-line. 
//The threads should count the number characters that are in the .class and .java files for this project, putting their totals into the following variable:
//public static long count = 0;

//At the end of the program, display the total count.
//Run the program with a thread count of 8, and 16 threads, using all three options for 
// locking (default no locking, --ReentrantLock, and --AtomicLong). 
//Do you see any difference in the value reported by count for the differences in threads and locking options?

//USES THE FOLLOWING CLASSES:
//package-info.java
//Lesson5Concurrent.java
//countText.java
//atomicCounter.java
//employee.txt
//JobResult.124432.txt

//

//      RESULTS

// METHOD				THREADS USED		RESULT
// 1 default			8					13645
// 2 Reentrant			8					13645
// 3 Atomic				8					8192
// 1 default			16					13645
// 2 Reentrant			16					13645
// 3 Atomic				16					8192

// The correct answer is 13645
// The atomic count is over-iterating the characters in the string. I've tried to add some delays, but I think the
//   use of a buffered reader does not work well with the atomic counter.  It is also returning IO Exceptions.