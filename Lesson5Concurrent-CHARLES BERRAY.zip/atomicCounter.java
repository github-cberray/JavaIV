package assignment5;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.atomic.AtomicInteger;


/*
 * atomicCounter.java - this class runs the incremental counter for characters in a passed string name of a file
 */
public class atomicCounter {

	final AtomicInteger counter = new AtomicInteger(0);

	/*
	 * sendAtomThreads - function that incrementally counts characters and returns them to an AtomicInteger counter
	 */
	public void sendAtomThreads(String strAtom)throws IOException, InterruptedException{

		FileInputStream fis = new FileInputStream(strAtom);
		InputStreamReader reader = new InputStreamReader(fis);
		//Iterate of the number of threads required
		for (int i=0;i<4;i++) {//i<Lesson5Concurrent.getThreads()

			new Thread(new Runnable() {

				public void run() {
					char[] chars;
					try {
						chars = reader.toString().toCharArray();
						int data;
						while ((data=reader.read())!=-1) {
							counter.addAndGet(1);
							try {
								Thread.currentThread().sleep(0);
							} catch (InterruptedException e) {	e.printStackTrace();	}
						}
					} catch (IOException e) {//System.out.println("Run error, IO Exception");
					} catch (NullPointerException e) {	//System.out.println("Run error, Null Pointer Exception");
					}
				}

			})
			.start();
		}
		fis.close();
		Thread.currentThread().sleep(0);
		Thread.currentThread().join(100);
		Lesson5Concurrent.setCount(getCount());

	}
	/*
	 * getCount - function to return the value of the counter
	 */
	public int getCount() throws InterruptedException {
		Thread.currentThread().join(100);
		return counter.get();
	}

}
