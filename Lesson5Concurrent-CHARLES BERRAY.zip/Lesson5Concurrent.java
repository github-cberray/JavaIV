package assignment5;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/* Lesson5Concurrent.java - Java console application that thread specification, locking choice, and counts characters in the thread.
 *  - Accepts "--num-threads NUMBER-OF-THREADS" where you can specify how many threads to create. (defaultNoLocking)
 *  - Accepts "--ReentrantLock" if  you want to use locking. By default you do not use any locking (ReentrantLock)
 *  - Accepts "--AtomicLong" if you want to use AtomicLong. By default you do not use any locking. (AtomicLong)
 *  
 *  - counts characters in this thread and returns in public static long count variable. Then displays it to console.
 *  
 *  - runs this with 8 threads, and with 16 threads, using all three above options.
 *  
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 7.25.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 */
public class Lesson5Concurrent {
	public static int threads=8;
	public static int method=1;
	public static long count=0;
	public static long eCount=0;


	static BufferedReader reader = null;

	// GETTERS AND SETTERS
	public static int getThreads() {		return threads;	}
	public static void setThreads(int threads) {		Lesson5Concurrent.threads = threads;	}
	public static int getMethod() {		return method;	}
	public static void setMethod(int method) {		Lesson5Concurrent.method = method;	}
	public static long getCount() {		return count;	}
	public static void setCount(long count) {		Lesson5Concurrent.count = count;	}

	/*
	 * threadNum - takes user input to set the number of threads to a static int threads
	 */
	public void threadNum() throws IOException {
		System.out.println("Enter the number of threads to use, 8 or 16");
		// Enter data using BufferReader
		BufferedReader readThreads = new BufferedReader(new InputStreamReader(System.in));
		String strThreads = readThreads.readLine();
		setThreads(Integer.parseInt(strThreads));
	}

	/*
	 * methodNum - takes user input for the method to perform counting operation
	 */
	public void methodNum()throws IOException{
		System.out.println("Enter your choice of count method: ");
		System.out.println("  1 for default, no locking");
		System.out.println("  2 for re-entrant lock - uses locking");
		System.out.println("  3 for atomic long");

		// Enter data using BufferReader
		BufferedReader readMethod = new BufferedReader(new InputStreamReader(System.in));
		String strMethod = readMethod.readLine();

		// Printing the selection back for the user
		switch (strMethod) {
		case "2":
			setMethod(2);
			//System.out.println("2. --Reentrant Lock ");
			break;
		case "3":
			setMethod(3);
			//System.out.println("3. --AtomicLong using ");
			break;
		default:
			setMethod(1);
			//System.out.println("1. --num-threads NUMBER-OF-THREADS ");
			break;
		}
	}

	/*
	 * ReentrantLock - this is the resource that is sequentially tapped by the locking---------------------------
	 */
	private static ReentrantLock lock = new ReentrantLock();
	// The constrained resource we wish to serially lock/unlock for threads
	// Didn't use this one
	private static void accessResourceOrBlocked(String fileName) {
		lock.lock();
		try {
			//do the access of the resource here, specifically incrementing the counter
			FileInputStream fis = new FileInputStream(fileName);
			InputStreamReader input = new InputStreamReader(fis);
			BufferedReader reader = new BufferedReader(input);

			long charCount=0;//Lesson5Concurrent.getCount();
			String data;
			while ((data=reader.readLine())!=null) {
				charCount+=data.length();
			}

			eCount=charCount;
			fis.close();

		} catch (Exception e) {
			System.out.println("couldn't get the resource work done");
		} finally {	lock.unlock();
		}

	}
	//Didn't use this one
	private static void accessResourceOrDoElse() {
		boolean lockAcquired = lock.tryLock();
		if(lockAcquired) {
			try {
				//do the access of the resource here, specifically incrementing the counter

			} catch (Exception e) {
				System.out.println("couldn't get the resource work done");
			} finally {	lock.unlock();
			}
		}else {
			//do something else
			System.out.println("lock not acquired, doing something else");
		}
	}
	//This function counts, or waits to count, and locks while doing so
	private static void accessResourceOrWait(String fileName) throws InterruptedException {
		boolean lockAcquired = lock.tryLock(0, TimeUnit.SECONDS);
		if(lockAcquired) {
			try {
				//do the access of the resource here, specifically incrementing the counter
				FileInputStream fis = new FileInputStream(fileName);
				InputStreamReader input = new InputStreamReader(fis);
				BufferedReader reader = new BufferedReader(input);

				long charCount=0;//Lesson5Concurrent.getCount();
				String data;
				while ((data=reader.readLine())!=null) {
					charCount+=data.length();
				}

				eCount=charCount;
				fis.close();

			} catch (Exception e) {
				System.out.println("couldn't get the resource work done");
			} finally {	lock.unlock();
			}
		}else {
			//do something else
			//System.out.println("lock not acquired, doing something else");
		}
	}
	
	private static void combineFiles() throws IOException {
		final String fileName1="C:\\Users\\19209\\eclipse-workspace\\JAVAIV\\src\\assignment5\\atomicCounter.java";
		final String fileName2="C:\\Users\\19209\\eclipse-workspace\\JAVAIV\\src\\assignment5\\Lesson5Concurrent.java";
		final String fileName3="C:\\Users\\19209\\eclipse-workspace\\JAVAIV\\src\\assignment5\\package-info.java";
		final String outputFile = "outputtext.txt";
		// Read in the file as a string

		// PrintWriter object for file3.txt
        PrintWriter pw = new PrintWriter(outputFile);
          
        // BufferedReader object for file1.txt
        BufferedReader br = new BufferedReader(new FileReader(fileName1));
          
        String line = br.readLine();
          
        // loop to copy each line of file1.txt to  file3.txt
        while (line != null){
            pw.println(line);
            line = br.readLine();
        }
          
        br = new BufferedReader(new FileReader(fileName2));
        line = br.readLine();
          
        // loop to copy each line of file2.txt to  file3.txt
        while(line != null) {
            pw.println(line);
            line = br.readLine();
        }
          
        br = new BufferedReader(new FileReader(fileName3));
        line = br.readLine();
          
        // loop to copy each line of file2.txt to  file3.txt
        while(line != null) {
            pw.println(line);
            line = br.readLine();
        }
        
        pw.flush();
          
        // closing resources
        br.close();
        pw.close();
              
	}

	//main method - conducts counting of two pre-chosen text files in the directory
	public static void main(String[] args) throws IOException, InterruptedException, ExecutionException {
		// GET DATA FROM USER ON THREADS DESIRED AND METHOD TO COUNT
		Lesson5Concurrent lc = new Lesson5Concurrent();
		lc.combineFiles();//combines the three input files into one text file
		lc.threadNum();//prompt user for number of threads
		lc.methodNum();//prompt user for count method

		// CONDUCT THE COUNT USING SWITCH CASE based upon the counting method chosen

		switch (getMethod()) {

		case 2:  //  REENTRANT LOCK------------------------------------------------------------------------------------

			System.out.print("2. --Reentrant Lock "+threads+" threads: ");
			for (int ii=0; ii<threads;ii++) {
				Thread t1 = new Thread(()->{
					accessResourceOrBlocked("outputtext.txt");					
				});
				t1.start();
				Thread.sleep(10);
			}
			Thread.sleep(10);
			setCount(eCount);
			break;

		case 3:  //  ATOMIC LONG--------------------------------------------------------------------------------------

			System.out.print("3. --AtomicLong using "+threads+" threads: ");
			atomicCounter ac = new atomicCounter();
			ac.sendAtomThreads("outputtext.txt");
			Thread.currentThread().join(100);
			break;

		default:  //  DEFAULT NO LOCKING-------------------------------------------------------------------------------
			System.out.print("1. Default No Locking "+threads+" threads: ");
			Runnable empCount=(()->{// function for no locking employee text file counting

				FileInputStream fis=null;
				try {
					fis = new FileInputStream("outputtext.txt");
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				InputStreamReader input = new InputStreamReader(fis);
				BufferedReader reader = new BufferedReader(input);
				long charCount=0;
				String data;
				try {
					while ((data=reader.readLine())!=null) {
						charCount+=data.length();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
				
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				try {
					Thread.currentThread().join(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				eCount=charCount;
			});

			ExecutorService executor = Executors.newFixedThreadPool(threads);

			executor.execute(empCount);
			Future result = executor.submit(empCount);
			Thread.currentThread().join(100);
			if (result.get()==null) {
			setCount(eCount);	
			}
			
			executor.shutdown();
			break;
		}

		// CLOSE AND GIVE RESULT TO USER---------------------------------------------------------------------------------
		lock.lock();
		try {
			//access the resource that is needed, the character count
			System.out.println("Result: "+getCount());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {	
			System.out.println("done");
			lock.unlock();
		}

	}

}
