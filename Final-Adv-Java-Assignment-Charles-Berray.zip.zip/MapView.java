package com.fathomcurve.Lesson7;

import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

/**
 * MapView.java - this class provides a frame for viewing a map, using the useGoogleMap class
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class MapView extends JFrame{
	String mvTitle;
	public String getMvTitle() {		return mvTitle;	}
	public void setMvTitle(String mvTitle) {		this.mvTitle = mvTitle;	}

	public MapView(String title, DBModel model, JFrame oldFrame) {
		this.setSize(1000, 900);//width, height
		
		setMvTitle(title);
		super.setTitle(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		//JFrame frameLoc = new JFrame("Location View");
		
		//SET LAYOUT
		JPanel panel1 = new JPanel();
		GroupLayout layout1 = new GroupLayout(panel1);
		layout1.setAutoCreateGaps(true);
		panel1.setSize(150, 50);

		JPanel panel2 = new JPanel();
		GroupLayout layout2 = new GroupLayout(panel2);
		layout2.setAutoCreateGaps(true);
		panel2.setSize(150, 50);

		// -- create map panel and populate with existing lat and lon
		useGoogleMap mapPanel = new useGoogleMap(model.getLatitude(), model.getLongitude());
		BoxLayout mapLayout = new BoxLayout(mapPanel, EXIT_ON_CLOSE);
		//mapPanel.setMaximumSize(getMaximumSize());
		mapPanel.setSize(1000,800);
		mapPanel.setVisible(false);

		JPanel masterPanel = new JPanel();
		BoxLayout masterLayout = new BoxLayout(masterPanel, BoxLayout.PAGE_AXIS);
		masterPanel.setLayout(masterLayout);
		//masterPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);

		//CREATE COMPONENTS
		//JLabel lblOwnerID = new JLabel (model.getUserFullName()+ ", ID: " + model.getTheID());
		JLabel lblOwnerID = new JLabel (model.getUserFullName()+ model.getTheID());
		JLabel lblLocName = new JLabel( model.getLocName());
		JLabel lblCoord = new JLabel(model.getLatitude()+", "+model.getLongitude());

		JButton btnReturn=new JButton("Go to Locations View");
		JButton btnBrowser=new JButton("Open Browser View");
		JButton btnWeather = new JButton("See the Weather");

		
		//ADD COMPONENTS TO LAYOUT

		layout1.setHorizontalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						//.addComponent(lblOwnerID)
						.addComponent(lblLocName)
						.addComponent(lblCoord))
				);
		layout1.setVerticalGroup(
				layout1.createSequentialGroup()
						//.addComponent(lblOwnerID)
						.addComponent(lblLocName)
						.addComponent(lblCoord)
				);

		layout2.setHorizontalGroup(
				layout2.createSequentialGroup()
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(btnWeather)
						.addComponent(btnReturn)
						.addComponent(btnBrowser))
				);
		layout2.setVerticalGroup(
				layout2.createSequentialGroup()
						.addComponent(btnReturn)
						.addComponent(btnWeather)
						.addComponent(btnBrowser)
				);



// -- Add panels into master panel
		
		masterPanel.add(panel1);
		masterPanel.add(panel2);
		masterPanel.add(mapPanel);


		this.add(masterPanel);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		//this.pack();
		oldFrame.dispose();
		
		
		//ADD BEHAVIORS
		
		// -- CREATE LOCATION
		btnReturn.addActionListener(new ActionListener() {// Takes us back to the LOCATIONS page, carries the values over
			public void actionPerformed(ActionEvent ll){
				System.out.println("This is where we return to the locations page");
				//open the location view
				LocView lv = new LocView("Location View", model, MapView.this);
				lv.txtLatitude.setText(String.valueOf(model.getLatitude()));
				lv.txtLongitude.setText(String.valueOf(model.getLongitude()));
				lv.txtLocName.setText(model.getLocName());
				//lv.txtLocTag.set
				lv.txtOwnerID.setText(model.getOwnerID());
				lv.txtShareFriendID.setText(model.getShareFriendID());
				
			}
		});
		btnBrowser.addActionListener(new ActionListener() {// RETURN TO ACCOUNT VIEW
			public void actionPerformed(ActionEvent ll){
				System.out.println("this is where we return to the main menu and close this window");
				//open the location view
				
Webbrowser wb = new Webbrowser("Simple Browser");

					//StartView sv=new StartView("Fishing Location Manager", model, MapView.this);

				
			}
		});
		
		btnWeather.addActionListener(new ActionListener() {// RETURN TO ACCOUNT VIEW
			public void actionPerformed(ActionEvent ll){
				System.out.println("this is where we return to the main menu and close this window");
				//open the location view

				if (model.getUserFullName()==null) {
					try {
						WeatherView wv= new WeatherView("Weather View", model, "weather", MapView.this);
					} catch (MalformedURLException e) {
						System.out.println("Could not display the weather");
						StartView sv=new StartView("Fishing Location Manager", model, MapView.this);
					}
				}
			}
		});
	}

}
