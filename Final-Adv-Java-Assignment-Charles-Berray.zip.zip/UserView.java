package com.fathomcurve.Lesson7;

import java.awt.BorderLayout;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.DBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

/**
 * UserView.java - this class allows for the view of the account setup, to create a new user
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class UserView extends JFrame {

	String uvTitle;
	public String getUvTitle() {		return uvTitle;	}
	public void setUvTitle(String uvTitle) {		this.uvTitle = uvTitle;	}
	
	public UserView(DBModel model, String title, JFrame oldFrame){

		this.setSize(1300, 1200);//width, height
		
		setUvTitle(title);
		super.setTitle(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		//JFrame frameLoc = new JFrame("Location View");
		
		//SET LAYOUT
		JPanel panel1 = new JPanel();
		GroupLayout layout1 = new GroupLayout(panel1);
		layout1.setAutoCreateGaps(true);
		layout1.setAutoCreateContainerGaps(true);
		panel1.setLayout(layout1);

		JPanel panel2 = new JPanel();
		GroupLayout layout2 = new GroupLayout(panel2);
		layout2.setAutoCreateGaps(true);
		panel2.setLayout(layout2);

		JPanel panel3 = new JPanel();
		GroupLayout layout3 = new GroupLayout(panel3);
		layout3.setAutoCreateGaps(true);
		panel3.setLayout(new FlowLayout());

		JPanel panel4 = new JPanel();
		GroupLayout layout4 = new GroupLayout(panel4);
		layout4.setAutoCreateGaps(true);
		panel4.setLayout(new FlowLayout());
		
		//CREATE COMPONENTS
		JLabel fakeLabel = new JLabel("  Account View ");
		try {
			if(model.getTheID()==null) {
				fakeLabel = new JLabel("  Account View ");
			} else {
			String idNow = model.getTheID();
			fakeLabel = new JLabel("  Account View for "+idNow);
			}
		} catch (Exception e1) {
			fakeLabel = new JLabel("  Account View ");
		}

		
		// -- FIRST NAME
		JLabel lblUserFullName = new JLabel("User Full Name (First Last)");
		JTextField txtUserFullName= new JTextField(20);
		try {
			if(model.getUserFullName()==null) {
				//do nothing
			}else {
				txtUserFullName.setText(model.getUserFullName());
				txtUserFullName.setEditable(false);
			}
		} catch (Exception e1) {
			// do nothing, the fullname field is empty (null)
		}

		// -- LAST NAME
		JLabel lblUserLogin= new JLabel("Username:");
		JTextField txtUserLogin = new JTextField(20);

		// -- PASSWORD
		JLabel lblPassword = new JLabel("Password:");
		JPasswordField txtPassword = new JPasswordField(15);

		// -- SHARING MY LOCATION
		JLabel lblShareLocTF = new JLabel("Check to share your location with friends");
		JCheckBox ckShareLocTF = new JCheckBox();

		// -- CREATE BUTTON
		JButton btnCreate=new JButton("Create User");
		
		// -- LOCATION VIEW BUTTON
		JButton btnLocationView=new JButton("Create some locations");
		btnLocationView.setVisible(false);

		//ADD COMPONENTS TO PANEL
		Container c1 = new Container();
		Container c2 = new Container();
		Container c3 = new Container();
		Container c4 = new Container();
	
		layout1.setHorizontalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(fakeLabel)
						.addComponent(lblUserFullName)
						.addComponent(lblUserLogin))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(txtUserFullName)
						.addComponent(txtUserLogin))
				);
		layout1.setVerticalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(fakeLabel))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblUserFullName)
						.addComponent(txtUserFullName))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(lblUserLogin)
						.addComponent(txtUserLogin))
				);
		
		layout2.setHorizontalGroup(
				layout2.createSequentialGroup()
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblPassword)
						.addComponent(lblShareLocTF))
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(txtPassword)
						.addComponent(ckShareLocTF))
				);
		layout2.setVerticalGroup(
				layout2.createSequentialGroup()
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblPassword)
						.addComponent(txtPassword))
						.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(lblShareLocTF)
						.addComponent(ckShareLocTF))
				);
		
		layout3.setHorizontalGroup(
				layout3.createSequentialGroup()
				.addGroup(layout3.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(btnCreate))
				.addGroup(layout3.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(btnLocationView))
				);
		layout3.setVerticalGroup(
				layout3.createSequentialGroup()
				.addGroup(layout3.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(btnCreate))
						.addGroup(layout3.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(btnLocationView))
				);
		
		//Finally, a layout to hold the containers above
		layout4.setHorizontalGroup(
				layout4.createSequentialGroup()
				.addGroup(layout4.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(panel1)
						.addComponent(panel2))
						.addGroup(layout4.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(panel3))
				);
		layout4.setVerticalGroup(
				layout4.createSequentialGroup()
						.addComponent(panel1)
						.addComponent(panel2)
						.addComponent(panel3)
				);
		
		this.add(panel4);
		oldFrame.dispose();


		//ADD BEHAVIORS

		// -- CREATE USER
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ll){
				System.out.println("Fire off the creation of a user");
				//create database connection
				String connectionString = "mongodb+srv://MongoDbUser1:_YXF9gFW2nkwqsJ@cluster0.u12zz.mongodb.net/test?authSource=admin&replicaSet=atlas-t7q7ah-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
				try (MongoClient mongoClient = MongoClients.create(connectionString)){
					MongoDatabase database = mongoClient.getDatabase("SPOTS");
					//MongoCollection <Document> collection = database.getCollection("Account");
					MongoCollection <Document> userCollection = database.getCollection("Users");
					model.setUserCollection(database.getCollection("Users"));
					MongoCollection <Document> locCollection = database.getCollection("Locs");
					MongoCollection <Document> locNoteCollection = database.getCollection("LocNotes");

					//create a new user in database
					// -- set values in model
					model.setUserPassword(String.valueOf(txtPassword.getPassword()));
					model.setUserFullName(txtUserFullName.getText());
					model.setUserLogin(txtUserLogin.getText());
					model.setShareLocTF(ckShareLocTF.isSelected());
					// -- change the view after creation
					btnLocationView.setVisible(true);
					btnCreate.setVisible(false);
					UserView.this.pack();
					// -- Append to the user table, and return the string of the _id
					String theID = model.createUserGetID(userCollection, model.getUserPassword(), model.getUserFullName(), model.getUserLogin(), model.isShareLocTF());
					model.setTheID(theID);
					model.setOwnerID(theID);
					System.out.println(theID);
					
					DBObject userObj=null;;
					try {
						userObj = model.readFromIDGetUser(userCollection,theID);
		
						System.out.println(userObj.toString());
					} catch (Exception e) {
						System.out.println("Unable to read from ID to get the user object");
						e.printStackTrace();
					}
					try {
						String idString = model.readFromDocGetID(userCollection, userObj);
						System.out.println(idString);
					} catch (Exception e) {
						System.out.println("Unable to read from object to get user ID");
						e.printStackTrace();
					}
					//System.out.println( model.readFromDocGetID(userCollection, model.readFromIDGetUser(userCollection,theID)));

				} catch (Exception e) {
					System.out.println("Updating values failed.");
				}

			}
		});
		
		
		// -- LOCATION VIEW
		btnLocationView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ll){
				System.out.println("Fire up the location view");
				//open the location view
				String connectionString = "mongodb+srv://MongoDbUser1:_YXF9gFW2nkwqsJ@cluster0.u12zz.mongodb.net/test?authSource=admin&replicaSet=atlas-t7q7ah-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
				try (MongoClient mongoClient = MongoClients.create(connectionString)){
					MongoDatabase database = mongoClient.getDatabase("SPOTS");
					//MongoCollection <Document> collection = database.getCollection("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXAccount");
					MongoCollection <Document> userCollection = database.getCollection("Users");
					model.setUserCollection(database.getCollection("Users"));
					MongoCollection <Document> locCollection = database.getCollection("Locs");
					model.setLocCollection(database.getCollection("Locs"));
					MongoCollection <Document> locNoteCollection = database.getCollection("LocNotes");
					LocView lv = new LocView("Location View",model, UserView.this);
					lv.setBounds(20,20,1300,1000);//horiz axis, vert axis, width, height 
					lv.setVisible(true);

				} catch (Exception e) {
					System.out.println("Updating values failed.");
				}	
			}
		});

	}

}
