package com.fathomcurve.Lesson7;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class Html {

	public static void main(String[] args) throws MalformedURLException {
		String weatherApiKey = "4bf5762dc678b0b8ff209bb097a8fa07";
		URL url = new URL("http://maps.openweathermap.org/maps/2.0/weather/{op}/{z}/{x}/{y}?appid="+weatherApiKey);

		String html = "HTTP/1.0 200 OK\r\n"
				+ "\r\n"
				+ "Content-Type: text/html\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "<html>\r\n"
				+ "	<head><title>My Assignment</title></head>\r\n"
				+ "		<body>\r\n"
				+ "			<h1>Java Networking</h1>\r\n"
				+ "			<div class=\"weather-container\">\r\n"
				+ "				<img class=\"icon\">\r\n"
				+ "				<p class \"weather\"></p>\r\n"
				+ "				<p class \"temp\"></p>\r\n"
				+ "			</div>\r\n"
				+ "		</body>\r\n"
				+ "</html>";
		File f = new File(".\\instructions.html");
		
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(f));
			bw.write(html);
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}
