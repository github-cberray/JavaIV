package com.fathomcurve.Lesson7;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * WeatherView.java - this class provides a view of a weather map, readme html or bug report html depending upon pagetype value
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class WeatherView extends JFrame{
	String mvTitle;
	public String getMvTitle() {		return mvTitle;	}
	public void setMvTitle(String mvTitle) {		this.mvTitle = mvTitle;	}

	public WeatherView(String title, DBModel model, String pageType, JFrame oldFrame) throws MalformedURLException {
		this.setSize(1000, 900);//width, height
		
		setMvTitle(title);
		super.setTitle(title);
		//this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		//JFrame frameLoc = new JFrame("Location View");
		
		//SET LAYOUT
		JPanel panel1 = new JPanel();
		GroupLayout layout1 = new GroupLayout(panel1);
		layout1.setAutoCreateGaps(true);
		panel1.setSize(150, 50);

		JPanel panel2 = new JPanel();
		GroupLayout layout2 = new GroupLayout(panel2);
		layout2.setAutoCreateGaps(true);
		panel2.setSize(150, 50);

		// -- create map panel and populate with existing lat and lon
		useWeatherMap mapPanel = new useWeatherMap(model.getLatitude(), model.getLongitude(), pageType);
		BoxLayout mapLayout = new BoxLayout(mapPanel, EXIT_ON_CLOSE);
		//mapPanel.setMaximumSize(getMaximumSize());
		mapPanel.setSize(1000,800);
		mapPanel.setVisible(false);

		JPanel masterPanel = new JPanel();
		BoxLayout masterLayout = new BoxLayout(masterPanel, BoxLayout.PAGE_AXIS);
		masterPanel.setLayout(masterLayout);
		//masterPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);

		//CREATE COMPONENTS
		//JLabel lblOwnerID = new JLabel (model.getUserFullName()+ ", ID: " + model.getTheID());
		JLabel lblOwnerID = new JLabel (model.getUserFullName()+ model.getTheID());
		JLabel lblLocName = new JLabel( model.getLocName());
		JLabel lblCoord = new JLabel(model.getLatitude()+", "+model.getLongitude());

		JButton btnReturn=new JButton("Go to Locations View");
		JButton btnExit=new JButton("Go to Login Screen");

		
		//ADD COMPONENTS TO LAYOUT

		layout1.setHorizontalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						//.addComponent(lblOwnerID)
						.addComponent(lblLocName)
						.addComponent(lblCoord))
				);
		layout1.setVerticalGroup(
				layout1.createSequentialGroup()
						//.addComponent(lblOwnerID)
						.addComponent(lblLocName)
						.addComponent(lblCoord)
				);

		layout2.setHorizontalGroup(
				layout2.createSequentialGroup()
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(btnReturn)
						.addComponent(btnExit))
				);
		layout2.setVerticalGroup(
				layout2.createSequentialGroup()
						.addComponent(btnReturn)
						.addComponent(btnExit)
				);



// -- Add panels into master panel
		
		masterPanel.add(panel1);
		masterPanel.add(panel2);
		masterPanel.add(mapPanel);


		this.add(masterPanel);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		//this.pack();
		oldFrame.dispose();
		
		//ADD BEHAVIORS
		
		// -- CREATE LOCATION
		btnReturn.addActionListener(new ActionListener() {// Takes us back to the LOCATIONS page, carries the values over
			public void actionPerformed(ActionEvent ll){
				System.out.println("This is where go to the locations page");
				//open the location view
				LocView lv = new LocView("Location View", model, WeatherView.this);
				lv.txtLatitude.setText(String.valueOf(model.getLatitude()));
				lv.txtLongitude.setText(String.valueOf(model.getLongitude()));
				lv.txtLocName.setText(model.getLocName());
				//lv.txtLocTag.set
				lv.txtOwnerID.setText(model.getOwnerID());
				lv.txtShareFriendID.setText(model.getShareFriendID());
				
			}
		});
		
		btnExit.addActionListener(new ActionListener() {// RETURN TO ACCOUNT VIEW
			public void actionPerformed(ActionEvent ll){
				System.out.println("this is where we go to the login screen");
				//open the location view
				

					LoginView sv=new LoginView("Fishing Location Manager", model, WeatherView.this);

				
			}
		});
		
	}

}

