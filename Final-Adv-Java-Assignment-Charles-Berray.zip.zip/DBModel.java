package com.fathomcurve.Lesson7;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bson.BSONObject;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.InsertOneResult;


/**
 * DBModel.java - this class accepts content from an existing SQL file, imports it, then appends it to an existing database
 *   called COREJAVA in a MongoDB. It works within a cluster of the COREJAVA called Cluster0.
 * 
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class DBModel {
	//VARIABLES & CONSTANTS
	String userFullName, userLogin, userPassword, userNum, theID, theLOC;
	String locName, ownerID, shareFriendID, locationID, note, noteDate;
	double latitude, longitude;
	boolean shareNoteTF, shareLocTF;
	List<String> locTag;

	MongoCollection <Document> userCollection;
	MongoCollection <Document> locCollection;
	MongoCollection <Document> locNoteCollection;

	public MongoCollection<Document> getUserCollection() {		return userCollection;	}
	public MongoCollection<Document> getLocCollection() {		return locCollection;	}
	public MongoCollection<Document> getLocNoteCollection() {		return locNoteCollection;	}
	public void setUserCollection(MongoCollection<Document> userCollection) {		this.userCollection = userCollection;	}
	public void setLocCollection(MongoCollection<Document> locCollection) {		this.locCollection = locCollection;	}
	public void setLocNoteCollection(MongoCollection<Document> locNoteCollection) {		this.locNoteCollection = locNoteCollection;	}
	
	
	//GETTERS
	public String getUserFullName() {									return userFullName;	}
	public String getUserLogin() {									return userLogin;	}
	public String getUserPassword() {										return userPassword;	}
	public String getLocName() {										return locName;	}
	public String getOwnerID() {										return ownerID;	}
	public List <String> getLocTag() {											return locTag;	}
	public String getShareFriendID() {									return shareFriendID;	}
	public String getLocationID() {										return locationID;	}
	public String getNote() {											return note;	}
	public double getLatitude() {										return latitude;	}
	public double getLongitude() {										return longitude;	}
	public String getNoteDate() {										return noteDate;	}
	public boolean isShareNoteTF() {									return shareNoteTF;	}
	public boolean isShareLocTF() {										return shareLocTF;	}



	//SETTERS
	public void setUserFullName(String userFullName) {									this.userFullName = userFullName;	}
	public void setUserLogin(String userLogin) {									this.userLogin = userLogin;	}

	public void setUserPassword(String userPassword) {											this.userPassword = userPassword;	}
	public void setLocName(String locName) {											this.locName = locName;	}
	public void setOwnerID(String ownerID) {											this.ownerID = ownerID;	}
	public void setLocTag(List<String> locTag) {												this.locTag = locTag;	}
	public void setShareFriendID(String shareFriendID) {								this.shareFriendID = shareFriendID;	}
	public void setLocationID(String locationID) {										this.locationID = locationID;	}
	public void setNote(String note) {													this.note = note;	}
	public void setLatitude(double latitude) {											this.latitude = latitude;	}
	public void setLongitude(double longitude) {										this.longitude = longitude;	}
	public void setNoteDate(String noteDate) {											this.noteDate = noteDate;	}
	public void setShareNoteTF(boolean shareNoteTF) {									this.shareNoteTF = shareNoteTF;	}
	public void setShareLocTF(boolean shareLocTF) {										this.shareLocTF = shareLocTF;	}

//GETTERS AND SETTERS FOR CURRENT SESSION VALUES NEEDED FOR UI
	public String getTheID() {		return theID;	}
	public void setTheID(String theID) {		this.theID = theID;	}
	public String getTheLOC() {		return theLOC;	}
	public void setTheLOC(String theLOC) {		this.theLOC = theLOC;	}
	
	
	/*
	 * DBModel - default constructor - not currently used
	 */
	public DBModel() {

	}
	
	
	//  *** *** CREATE *** ***
	/**
	 * createUser - this method takes a single set of user number and user name and appends them to the friends collection
	 * @param collection	MongoCollection		The MongoDB collection to which we are appending values
	 * @param userNum		int					The number of the user
	 * @param userName		String				The name of the user
	 * @return				boolean				True if successful in the document appending
	 */
	protected static boolean createUser(MongoCollection collection, String userPassword, String userFullName, String userLogin, boolean shareLocTF){
		try {
			InsertOneResult result = collection.insertOne(new Document()
					.append("User_ID", new ObjectId())
					.append("User_Num", userPassword)
					.append("User_FirstName", userFullName)
					.append("User_LastName", userLogin)
					.append("Shared_Loc_TF", shareLocTF));
			return true;
		} catch (MongoException me) {
			System.err.println("Unable to insert user due to an error: " + me);
			return false;
		}
	}

	protected String createUserGetID(@SuppressWarnings("rawtypes") MongoCollection collection, String userPassword, String userFullName, String userLogin, boolean shareLocTF){
		try {
			Document doc = new Document();
			doc.append("User_ID", new ObjectId());
			doc.append("User_Num", userPassword);
			doc.append("User_FirstName", userFullName);
			doc.append("User_LastName", userLogin);
			doc.append("Shared_Loc_TF", shareLocTF);
			collection.insertOne(doc);
			return doc.get("_id").toString();
		} catch (MongoException me) {
			System.err.println("Unable to insert user due to an error: " + me);
			return "ID not found";
		}
	}

	protected String checkPassword(MongoCollection collection, String userName, String password) {
		String aDoc="abc";
		String myID = "hi there";

		String connectionString = "mongodb+srv://MongoDbUser1:_YXF9gFW2nkwqsJ@cluster0.u12zz.mongodb.net/test?authSource=admin&replicaSet=atlas-t7q7ah-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
		try (MongoClient mongoClient = MongoClients.create(connectionString)){
			MongoDatabase database = mongoClient.getDatabase("SPOTS");
			MongoCollection <Document> userCollection =database.getCollection("Users");
			try (MongoCursor<Document> cur = userCollection.find().iterator()) {

				while (cur.hasNext()) {
					aDoc=cur.next().toString();

					if ((aDoc.contains(password))&&(aDoc.contains(userName))) {

						Pattern p = Pattern.compile("^\\bDocument\\{\\{\\_id=\\b+([a-z0-9]*)[,]+.*");
						Matcher m = p.matcher(aDoc);

						// if we find a match, get the group 
						if (m.find()) {
							myID = m.group(1);
						}
					}
				}
			} 
		}

		return myID;
	}
	
	
	
	
	protected BasicDBObject readFromIDGetUser(MongoCollection collection, String userID) {
	    BasicDBObject obj = new BasicDBObject();
	    obj.append("_id", userID);     
	    MongoCursor dbc = collection.find(obj).iterator();
	    
	    BasicDBObject query = new BasicDBObject();        
	    query.putAll((BSONObject)obj);
		return obj;
	}

	protected String readFromDocGetID(MongoCollection collection, DBObject obj) {
		String theID = (String) obj.get("_id");
		return theID;
	}
	
	protected String[][] readFromIDLocList(String userID) {
		String aDoc;
		List <String>theDocs = new ArrayList<String>();
		String[][] outputTable;
		
		String connectionString = "mongodb+srv://MongoDbUser1:_YXF9gFW2nkwqsJ@cluster0.u12zz.mongodb.net/test?authSource=admin&replicaSet=atlas-t7q7ah-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
		try (MongoClient mongoClient = MongoClients.create(connectionString)){
			MongoDatabase database = mongoClient.getDatabase("SPOTS");
			MongoCollection <Document> locCollection =database.getCollection("Locs");
			try (MongoCursor<Document> cur = locCollection.find().iterator()) {

				while (cur.hasNext()) {
					aDoc=cur.next().toString();
					theDocs.add(aDoc);
				}
			} 
		}
		outputTable = getLocDocElements(theDocs);
		String[][] filteredTable = new String [theDocs.size()][6];
		int ii=0;
		for (int ddoc = 0;ddoc<theDocs.size();ddoc++) {
			if (outputTable[ddoc][1].contains(userID)) {
				//add it to the filtered array
				//System.out.println("Found ID: "+outputTable[ddoc][1].toString());
				//System.out.println(theDocs.toString());
				for (int ffield = 0; ffield<6;ffield++) {
					try {
						filteredTable[ii][ffield]=outputTable[ddoc][ffield];

					} catch (Exception e) {
						// TODO Auto-generated catch block

					}
				}
				ii++;
			}
		}
		return filteredTable;
	}

		
	public String[][] getLocDocElements(List<String> inputList) {
		//Declarations
		List<String> theDocs = new ArrayList<String>();//A list array to use to hold the docs temporarily
		String anInputListDoc="";//a single long string of the inputList
		String[] brokenArray=new String[6];
		String[][] fullList=new String [inputList.size()][6];
		
		for (int dd=0; dd<inputList.size();dd++) { // this is an iteration from row to row
			anInputListDoc = inputList.get(dd);
			//inputList.add(anInputListDoc);

			brokenArray=breakDocToArray(anInputListDoc);//this is a row of data, each value, 6 elements
			//this returns a 6 elements in a single dim array, constituting one row of data

			// read this brokenArray into the multdimArray
			//  -- iterate each element into the row of the multidimArray
			for (int element=0; element<25;element++) {
				
				try {
					fullList[dd][element]=brokenArray[element];
				} catch (Exception e) {
					// TODO Auto-generated catch block
					
				}
			}

		}
		return fullList;
	}
	
	public String[] breakDocToArray(String anInputListDoc){
		//break string into pieces
		String[] docArray = anInputListDoc.split("=");
		String[] brokenArray = new String[5];
		
		for (int ii=0; ii<docArray.length; ii++) {
			String [] subArray = docArray[ii].split(",");
			//System.out.print("ii: "+ii+" ----------------------------- ");
			try {
				for (int jj=0; jj<docArray.length; jj++) {
					//System.out.println("subarray "+ jj + " is "+subArray[jj].toString());
					if((ii==3)&&(jj==0)) 
						brokenArray[0]=subArray[jj];//location name
					if((ii==4)&&(jj==0)) 
						brokenArray[1]=subArray[jj];//owner id
					if((ii==5)&&(jj==0)) 
						brokenArray[2]=subArray[jj];//latitude
					if((ii==6)&&(jj==0)) 
						brokenArray[3]=subArray[jj];//longitude
					if((ii==8)&&(jj==0)) 
						brokenArray[4]=subArray[jj];//sharefriendid
				}//end jj loop
			} catch (Exception e) {
				//do not loop
			}
		}//end ii loop
		return brokenArray;	//an array of one document of elements
	}

	/**
	 * readFromIDNoteList - method that takes a userID and returns filter 2D string array of only locations that Location_ID matches userID
	 * 
	 * @param userID String	The unique id number in mongodb for the user currently signed in
	 * @return	2D filtered string array where _id=userID
	 */
	protected String[][] readFromIDNoteList(String userID) {
		String aDoc;
		List <String>theDocs = new ArrayList<String>();
		String[][] outputTable;

		//Establish a connection to mongo location database
		String connectionString = "mongodb+srv://MongoDbUser1:_YXF9gFW2nkwqsJ@cluster0.u12zz.mongodb.net/test?authSource=admin&replicaSet=atlas-t7q7ah-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
		try (MongoClient mongoClient = MongoClients.create(connectionString)){
			MongoDatabase database = mongoClient.getDatabase("SPOTS");
			MongoCollection <Document> locCollection =database.getCollection("LocNotes");
			try (MongoCursor<Document> cur = locCollection.find().iterator()) {

				while (cur.hasNext()) {
					aDoc=cur.next().toString();
					theDocs.add(aDoc);
				}
			} 
		}
		// -- now we have a set of documents for all of the locations

		//Use method getLocNoteElements to build 2D string array with all of the locations
		outputTable = getLocNoteElements(theDocs);

		//Iterate through the documents to extract only those that match the user ID, return 2D string array filtered
		String[][] filteredTable = new String [theDocs.size()][6];
		int ii=0;
		for (int ddoc = 0;ddoc<theDocs.size();ddoc++) {
			if (outputTable[ddoc][2]==userID) {
				//add it to the filtered array
				for (int ffield = 0; ffield<6;ffield++) {
					filteredTable[ii][ffield]=outputTable[ddoc][ffield];
					ii++;
				}
			}
		}

		return filteredTable;//2D filtered string array where _id=userID
	}

	/**
	 * getLocNoteElements - method that takes string list of all location documents from mongo, and returns all locations broken into 2D string array
	 * @param inputList	ArrayList<String>	list of string form of each document from locations datatable in mongo
	 * @return
	 */
	public String[][] getLocNoteElements(List<String> inputList) {
		//Declarations
		List<String> theDocs = new ArrayList<String>();//A list array to use to hold the docs temporarily
		String anInputListDoc="";//a single long string of the inputList
		String[] brokenArray=new String[6];
		String[][] tableList=new String [inputList.size()][6];
		for (int dd=0; dd<inputList.size();dd++) { // this is an iteration from row to row
			anInputListDoc = inputList.get(dd);

			// Use method to breakdown the list into an array format through split of each row of data
			brokenArray=breakNoteToArray(anInputListDoc);//this is a row of data, each value, 6 elements
			//this returns a 6 elements in a single dim array, constituting one row of data

			//  -- iterate each element into the row of the multidimArray
			for (int element=0; element<6;element++) {
				tableList[dd][element]=brokenArray[element];
			}
		}
		return tableList;
	}

	/**
	 * breakNoteToArray - this method takes a string list of mongo location table documents into a 6 element string array
	 * @param anInputListDoc String	One mongo location datatable document
	 * @return
	 */
	public String[] breakNoteToArray(String anInputListDoc){
		//break string into pieces
		String[] docArray = anInputListDoc.split("=");//source document split into string elements
		String[] brokenArray = new String[6];//document used to enter the string elements we wish to keep in an array

		for (int ii=0; ii<docArray.length; ii++) {
			String [] subArray = docArray[ii].split(",");

			for (int jj=0; jj<docArray.length; jj++) {

				if((ii==1)&&(jj==0)) 
					brokenArray[0]=subArray[jj];
				if((ii==2)&&(jj==0)) 
					brokenArray[1]=subArray[jj];
				if((ii==3)&&(jj==0)) 
					brokenArray[2]=subArray[jj];
				if((ii==4)&&(jj==0)) 
					brokenArray[3]=subArray[jj];
				if((ii==5)&&(jj==0)) 
					brokenArray[4]=subArray[jj];
				if((ii==6)&&(jj==0)) 
					brokenArray[5]=subArray[jj];
			}//end jj loop
		}//end ii loop

		return brokenArray;	//an array of one document of elements
	}

	

	/*
	 * existingLatLong - method to determine if a latitude and longitude set already exists in the location datatable
	 */
	protected boolean existingLatLong(MongoCollection collection, double latitude, double longitude, String ownerID) {
		//search if lat long and owner exists, if so, return true
		BasicDBObject search = new BasicDBObject();
		search.put("Latitude", latitude);
		search.put("Longitude", longitude);
		search.put("Owner_ID", ownerID);
		BasicDBObject found = new BasicDBObject();
		found.putAll((BSONObject) search);
		System.out.println(found.toJson());
		return !found.isEmpty();
	}
	
	protected String idGetLastCoord(MongoCollection collection, String theID) {
		BasicDBObject search = new BasicDBObject();
		search.put("_id", theID);     
		BasicDBObject found = new BasicDBObject();        
		found.putAll((BSONObject)search);
		String theLat = (String) found.get("Latitude");
		String theLon = (String) found.get("Longitude");
		if (theLat.equals(null)) {
			theLat = "Not getting a value";
		}
		return theLat + ", " + theLon;

	}

protected void updateUser(MongoCollection collection, String id, String firstname, String lastname, String password, boolean share) {
	BasicDBObject search = new BasicDBObject();
    search.put("_id", theID);     
    BasicDBObject found = new BasicDBObject(); 
    found.putAll((BSONObject)search);
    
    if (found != null) {
    	System.out.println("Found the ID");
    	Bson updatedFN = new Document("User_FirstName", firstname);
    	Bson updateOperation = new Document("$set", updatedFN);
    	collection.updateOne(found, updateOperation);
    	System.out.println("First Name Updated");
    	
    	Bson updatedLN = new Document("User_LastName", lastname);
    	Bson updateOperation2 = new Document("$set", updatedLN);
    	collection.updateOne(found, updateOperation2);
    	System.out.println("Last Name Updated");
    	
    	Bson updatedPW = new Document("User_Num", password);
    	Bson updateOperation3 = new Document("$set", updatedPW);
    	collection.updateOne(found, updateOperation3);
    	System.out.println("Password Updated");
    	
    	Bson updatedSL = new Document("Shared_Loc_TF", share);
    	Bson updateOperation4 = new Document("$set", updatedSL);
    	collection.updateOne(found, updateOperation4);
    	System.out.println("Sharing Updated");
    	
    }
}
	
	
	/**
	 * createLoc - this method takes a single set of location values and appends them to the LOC collection
	 * @param collection	MongoCollection		The MongoDB collection to which we are appending values
	 * @param userNum		int					The number of the user
	 * @param locName		String				The name given to the location by the user
	 * @param latitude		double				The number value of the latitude
	 * @param longitude		double				The number value of the longitude
	 * @return				boolean				True if successful in the document appending
	 */
	protected static String createLoc(MongoCollection collection,String locName, String ownerID,  double latitude, double longitude, List <String> locTag, String shareFriendID){
		try {
			//InsertOneResult result = collection.insertOne(new Document()
					Document doc = new Document();
					doc.append("Location_ID", new ObjectId());
					doc.append("Location", locName);
					doc.append("Owner_ID", ownerID);
					doc.append("Latitude", latitude);
					doc.append("Longitude", longitude);
					doc.append("Location_Tag", locTag);
					doc.append("Shared_Friend_ID", shareFriendID);
					collection.insertOne(doc);
					
					return doc.get("_id").toString();
		} catch (MongoException me) {
			me.printStackTrace();
			System.err.println("Unable to insert location due to an error: " + me);
			return "Unable to save location due to an ID error";
		}
	}


protected static boolean createLocNote(MongoCollection collection, String locationID, String noteDate, String note, boolean shareNoteTF){
		try {

			InsertOneResult result = collection.insertOne(new Document()
					.append("LocNote_id", new ObjectId())
					.append("Location_ID", locationID)
					.append("Note_Date", noteDate)
					.append("Note", note)
					.append("Share_Note_TF", shareNoteTF));
			//.append("Tags", Arrays.asList("Java", "Advanced","IO")));
			return true;
		} catch (MongoException me) {
			System.err.println("Unable to insert location due to an error: " + me);
			return false;
		}
	}



//	/**
//	 * createLessons - this method appends a list of paired lesson numbers and titles into the collection, 
//	 *   prints the number of documents appended to the console
//	 * @param collection	MongoCollection		The MongoDB collection to which we are appending values
//	 * @param tablePairs	List<String>		Paired lesson number and title separated by a comma
//	 * @return				boolean				True if successful in the document appending
//	 */
//	private static boolean xxxxxxxxxxxxxxxxxxxxxxxxxcreateLessons(MongoCollection collection, List<String> tablePairs){
//
//		//Here we split each tablePair into two values, then append that pair into the Cluster0
//		int lessonNum=0;
//		String strTitle=null;
//		String delims = "[,]";
//		String[]tokens=null;
//		String tempNum=null;
//		String tempTitle=null;
//		for (int ii=0;ii<tablePairs.size();ii++) {
//			//split one tablePair into two strings
//			tokens = tablePairs.get(ii).split(delims);//String broken into pieces
//
//			//convert each string into a value for entry to the cluster
//			for (int tt=0;tt<tokens.length;tt++) {
//
//				//first remove quotes from lesson number if they exist
//				tempNum=tokens[0].replace("\'", "xx");
//
//				lessonNum=Integer.parseInt(tempNum);
//				tempNum=null;
//
//				//first remove quotes from title
//				tempTitle=tokens[1].replace("\'", "xx");
//				//next trim spaces from title
//				tempTitle = tempTitle.trim();
//				strTitle=tempTitle;
//				tempTitle=null;
//			}
//
//			//append the values into the cluster
//			try {
//				@SuppressWarnings("unchecked")
//				InsertOneResult result = collection.insertOne(new Document()
//						.append("_id", new ObjectId())
//						.append("Lesson_Num", lessonNum)
//						.append("Title", strTitle));
//				//.append("Tags", Arrays.asList("Java", "Advanced","IO")));
//
//			} catch (MongoException me) {
//				System.err.println("Unable to insert due to an error: " + me);
//				return false;
//			}
//
//			//clear the temp values to repeat
//			lessonNum=0;
//			strTitle=null;
//			tokens=null;
//		}
//		System.out.println("Inserted "+tablePairs.size()+" documents");
//		return true;
//	}
//
//	/**
//	 * deleteTitle - this method deletes documents from the collection containing a title
//	 * @param collection	MongoCollection		The MongoDB collection to which we are appending values
//	 * @param strTitle		String				The title of the lesson
//	 * @return				boolean				True if successful in deleting documents matching the string parameter
//	 */
//	private static boolean xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxdeleteTitle(MongoCollection collection, String strTitle) {
//		//removing any applicable titles from the collection
//		try {
//			collection.deleteMany(new Document("Title", strTitle));
//			return true;
//		} catch (Exception e) {
//			return false;
//		}
//	}
//
//	/**
//	 * deleteLessonNum - this method deletes documents from the collection containing a lesson number
//	 * @param collection	MongoCollection		The MongoDB collection to which we are using values
//	 * @param lessonNum		int					The number of the lesson
//	 * @return				boolean				True if successful in deleting documents containing the lesson number
//	 */
//	private static boolean xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxdeleteLessonNum(MongoCollection collection, int lessonNum) {
//		//removing any applicable lesson numbers from the collection
//		try {
//			collection.deleteMany(new Document("Lesson_Num", lessonNum));
//			return true;
//		} catch (Exception e) {
//			return false;
//		}
//	}
//
//	/**
//	 * deleteCollection - this method deletes all of the documents in the collection
//	 * @param collection	MongoCollection		The MongoDB collection to which we are appending values
//	 * @return				boolean				True if successful in deleting the documents from the collection
//	 */
//	private static boolean xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxdeleteCollection(MongoCollection collection) {
//		//removing all of the collection
//		try {
//			collection.deleteMany(new Document());
//			return true;
//		} catch (Exception e) {
//			return false;
//		}
//	}
//
//	/**
//	 * printFirstRecord - this method prints the information from lesson number 1 if it exists
//	 * @param collection	MongoCollection		The MongoDB collection to which we are appending values
//	 * @return				boolean				True if successful in finding and printing the document to the console
//	 */
//	private static boolean xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxprintFirstRecord(MongoCollection collection){
//		System.out.println( collection.find(new Document("Lesson_Num", 1)).first().toString());
//		return true;
//	}
//
//	/**
//	 * printDatabases - this method prints the names of all of the databases in the client connection to the console
//	 * @param mongoClient	MongoClient		The client we are connected
//	 */
//	private static void xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxprintDatabases(MongoClient mongoClient){
//		System.out.println("Databases: ");
//		MongoIterable<String> databaseNames = mongoClient.listDatabaseNames();
//		databaseNames.forEach(name->System.out.println(name));
//	}
//
//	/**
//	 * printAllRows - this method prints all of the documents from the cluster0 to the console
//	 * @param collection	MongoCollection		The MongoDB collection to which we are appending values
//	 */
//	private static void xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxprintAllRows(MongoCollection collection) {
//		FindIterable<Document> iterDoc = collection.find();
//		Iterator it = iterDoc.iterator();
//		while (it.hasNext()) {
//			System.out.println(it.next());
//		}
//	}
//
//	/**
//	 * readSQL - this method reads in the text from a file name into a string and returns that string
//	 * @param fileName		String		The path and name of the file
//	 * @return				String		The entire text contents read into a single string
//	 * @throws IOException	Exception	IO Exception if unable to read the file name
//	 */
//	private static String xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxreadSQL(String fileName) throws IOException {
//		// Read in the file as a string
//		FileInputStream fis = new FileInputStream(fileName);
//		byte [] byteStream = fis.readAllBytes();
//		String strDump = new String(byteStream,Charset.forName("UTF-8"));
//		return strDump;
//	}
//
//	/**
//	 * parseSQL - this method accepts a string, then parses it in preparation for appending to a mongo db as a List<String> 
//	 *  the source file has SQL content that must be parsed to first find the records, next to clean them,
//	 *  and finally to ignore unneeded content. The output is paired values of the lesson number and title separated by a comma
//	 * @param strLesson
//	 * @return
//	 */
//	private static List<String> xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxparseSQL(String strLesson) {
//		String sourceString = strLesson;
//		String delims = "[();]+";
//		String[]tokens = strLesson.split(delims);//String broken into pieces
//		List <String>tablePairs = new ArrayList<String>();//List to hold what we want to keep
//		//Iterate through the string to only add what we want into the list
//		for (int i=0; i<tokens.length;i++) {
//			if (!tokens[i].trim().contains(",")) {
//				//System.out.println(tokens[i]+" was Removed");
//			}else if(!tokens[i].contains("_")){
//				tablePairs.add(tokens[i].trim().replace("\'", ""));
//			}
//		}
//		return tablePairs;
//	}
//
//	/**
//	 * printCollectionFiltered - this method prints documents matching the title given to the console
//	 * @param collection	MongoCollection		The MongoDB collection to which we are appending values
//	 * @param strTitle		String				The title of the lesson
//	 */
//	private static void xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxprintCollectionFiltered(MongoCollection collection, String strTitle){
//		BasicDBObject whereQuery = new BasicDBObject();
//		whereQuery.put("Title", strTitle);
//		FindIterable iterDoc = collection.find(whereQuery);
//		Iterator it = iterDoc.iterator();
//		while (it.hasNext()) {
//			System.out.println(it.next());
//		}
//	}
}


