package com.fathomcurve.Lesson7;

import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import com.teamdev.jxbrowser.browser.Browser;
import com.teamdev.jxbrowser.engine.Engine;
import com.teamdev.jxbrowser.engine.EngineOptions;
import com.teamdev.jxbrowser.engine.RenderingMode;
import com.teamdev.jxbrowser.view.swing.BrowserView;

/**
 * useWeatherMap.java - this class provides a view of an html file
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class useWeatherMap extends JPanel{

	public useWeatherMap(double latitude, double longitude, String pageType) throws MalformedURLException {
		String dir = System.getProperty("user.dir");
		//System.out.println(dir);
		
		//String url="file:///C:/Users/19209/eclipse-workspace/Lesson8Project/src/main/java/com/fathomcurve/Lesson7/ReadFirst.html";
		//String myURL = "C:\\Users\\19209\\eclipse-workspace\\Lesson8Project";
		String url="file:///"+dir+"/src/main/java/com/fathomcurve/Lesson7/ReadFirst.html";
		
		switch (pageType) {
		case "weather":
			url = "https://forecast.weather.gov/MapClick.php?textField1="+ Double.valueOf(latitude)+"&textField2="+Double.valueOf(longitude);
			//url = "https://www.wunderground.com/wundermap?"+ Double.valueOf(latitude)+"&lon="+Double.valueOf(longitude);
			break;
		case "weatherdata":
			url = new String("https://api.openweathermap.org/data/2.5/weather?units=imperial&lat="+ Double.valueOf(latitude)+"&lon="+Double.valueOf(longitude)+"&appid=dd30ad7ff3b47c3a712c4ba5dc46d485");
			break;
		case "readfirst":
			//url="file:///C:/Users/19209/eclipse-workspace/Lesson8Project/src/main/java/com/fathomcurve/Lesson7/ReadFirst.html";
			url="file:///"+dir+"/src/main/java/com/fathomcurve/Lesson7/ReadFirst.html";
			break;
		case "bugreport":
			url="file:///"+dir+"/src/main/java/com/fathomcurve/Lesson7/BugReport.html";
			break;
			default:
				//something
				break;
		}
		String theURL = url;

		// Initialize Chromium.
		Engine engine = Engine.newInstance(
				EngineOptions.newBuilder(RenderingMode.HARDWARE_ACCELERATED)
				.licenseKey("1BNDHFSC1G028J7GPM0A9DP9QXATQZXMGRPBB8362YTDYHA7P7YDOUTWZJ20M3HPIEYW6P")
				.build());
		Browser browser = engine.newBrowser();

		BuildCoordURL bcu = new BuildCoordURL();

		SwingUtilities.invokeLater(() -> {
			//JFrame frame = new JFrame("Map Location");

			// Create and embed Swing BrowserView component to display web content.
			this.add(BrowserView.newInstance(browser));
			this.setSize(450, 450);

			//panel.setLocationRelativeTo(null);
			this.setVisible(true);

			// Load the required web page.
			//browser.navigation().loadUrl(bcu.BuildCoordURL(latitude, longitude));
			browser.navigation().loadUrl(theURL);



		});

	}
}