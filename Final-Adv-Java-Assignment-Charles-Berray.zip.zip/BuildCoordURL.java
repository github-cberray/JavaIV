package com.fathomcurve.Lesson7;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * BuildCoordURL - This class converts string pairs input for latitude and longitude and identifies one of three match types that can be used
 *   to convert them into a viable URL for google maps plotting. If unable to convert, it returns the generic google maps page.
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class BuildCoordURL {

	/*
	 * buildCoordDBL - method examines string for fitness, then converts to double decimal degree coordinate value, returns 0.0 on failure
	 */
	public double BuildCoordDBL(String strCoord) {
		 if (useString(strCoord)){
			   return calcLatOrLon(strCoord, coordType(strCoord));
			} else {
				return 0.0;
			}
	}
	
	
	/*
	 * BuildCoordURL - method takes input latitude and longitude string, tests them for fitness, and builds a google maps coordinate url
	 */
	public String BuildCoordURL(String latString, String lonString) {
		 if ((useString(latString)) && (useString(lonString))){
		   return doublesToURL( calcLatOrLon(latString,coordType(latString)), calcLatOrLon(latString,coordType(latString)) );
		} else {
			return "http://maps.google.com";
		}
	}
	
	/*
	 * BuildCoordURL - method takes input latitude and longitude double, tests them for fitness, and builds a google maps coordinate url
	 */
	public String BuildCoordURL(double latDouble, double lonDouble) {
		String theURL;
		try {
			theURL= doublesToURL( latDouble, lonDouble);
			return theURL;
		} catch (Exception e) {
			return "http://maps.google.com";
		}
	}
	/*
	 * latType - method to take input lat or lon string, and use Regex to ascertain the type of format entered, returns a text name for the type of format
	 */
	public static String coordType(String inputStr) {
		final String DBL_PAT = "^[+-]?[0-9]+\\.*[0-9]*|^[-]+\\s*|\\s*";
		final String DBL_SUFF = "^[+-]?[0-9]+\\.*[0-9]*\\s*[NnSsEeWw]?";
		final String DMS_PAT = "^[+-]?[0-9]+\\s+[0-9]*\\.*[0-9]*\\s*[0-9]*\\.*[0-9]*\\s*[NnSsEeWw]?";

		String matchType="false";
		Pattern pattern1 = Pattern.compile(DBL_PAT);
		Pattern pattern2 = Pattern.compile(DBL_SUFF);
		Pattern pattern9 = Pattern.compile(DMS_PAT);
		Matcher matcher;

		//SIMPLE DOUBLE
		matcher=pattern1.matcher(inputStr.toUpperCase().trim());
		if (matcher.matches()) {
			matchType="SIMPLE DOUBLE";
		}else {
			//SUFFIXED DOUBLE (Has a N or S)
			matcher=pattern2.matcher(inputStr.toUpperCase().trim());
			if (matcher.matches()) {
				matchType="SUFFIXED DOUBLE";
			}else {
				//DEGREE MINUTE SECOND (separated by spaces)
				matcher=pattern9.matcher(inputStr.toUpperCase().trim());
				if (matcher.matches()) {
					matchType="SPACED DMS";
				}else {
					matchType="Not matched at all";
				}
			}
		}
		return matchType;
	}

	/*
	 * suffixToSign - method uses Regex to take input lat or lon string and determine the appropriate positive or negative sign of the coordinate value
	 */
	public static String suffixToSign(String inputStr) {
		final String PAT_NEGATIVE = ".*S$|.*W$";
		Pattern patNeg = Pattern.compile(PAT_NEGATIVE);
		final String PAT_POSITIVE= ".*N$|.*E$";
		Pattern patPos = Pattern.compile(PAT_POSITIVE);
		
		String theSign="";
		Matcher matcherNeg=patNeg.matcher(inputStr.toUpperCase().trim());
		if (matcherNeg.matches()) {
				theSign="-";
		} 
		
		Matcher matcherPos=patPos.matcher(inputStr.toUpperCase().trim());
		if (matcherPos.matches()) {
				theSign="+";
		}
		return theSign;
		
	}
	
	/*
	 * DMSToDouble - method that takes an input lat or lon string  in DMS separated with spaces, and returns a value in degrees with decimal, clean and signed
	 */
	public static double DMSToDouble(String inputStr) {

		//Clean up input, remove extra spaces, make all uppercase
		inputStr=inputStr.trim().toUpperCase();

		//Get the positive or negative sign
		String suffixSign = suffixToSign(inputStr);
		String preSign = "";

		//  -- removes redundant negative signs
		if (inputStr.contains("-")) {
			preSign="-";
			inputStr=inputStr.replace("-", "");
		}
		if (inputStr.contains("+")) {
			inputStr=inputStr.replace("+", "");
		}

		// -- Break up the space separated strings into viable numbers
		String[] DMSParts =inputStr.split(" ");
		List<Double> DMSNums = new ArrayList<Double>();
		double str;
		for (String ss: DMSParts) {
			try {
				DMSNums.add(Double.valueOf(ss));
			} catch (Exception e) {
				//this will only be used when garbage or when minutes with decimal are entered (no seconds value)
				DMSNums.add(Double.valueOf("0"));
			}
		}
		//In the event the array was not filled with three entries, complete it with zeroes
			while (DMSNums.size()<2) {
				DMSNums.add(0.0);
			}


		//Make negative signs and convert number values into a single decimal value
		if (suffixSign=="-") {
			return  (-1)*(DMSNums.get(0)+DMSNums.get(1)/60+DMSNums.get(2)/3600);
		}else {
			if ((suffixSign=="")&&(preSign=="-")){
				return  (-1)*(DMSNums.get(0)+DMSNums.get(1)/60+DMSNums.get(2)/3600);
			} else {
				return  DMSNums.get(0)+DMSNums.get(1)/60+DMSNums.get(2)/3600;
			}
		}
	}

	/*
	 * calcLatOrLon - method that takes an input for latitude or longitude, and the predetermined format type, then converts it to a signed and clean double
	 */
	public static double calcLatOrLon(String inputStr, String inputType) {

		double outDoubleLat=0.0;
		String preSign="";
		if(inputStr.contains("-")) {
			preSign="-";
		}
		
		//CONVERT DMS TO DOUBLE
		if (inputType=="SPACED DMS") {
			outDoubleLat=DMSToDouble(inputStr);
		} else {

			//CONVERT SUFFIXED DOUBLE TO DOUBLE
			if (inputType=="SUFFIXED DOUBLE") {
				String suffixSign=suffixToSign(inputStr);

				//Clean up input, remove extra spaces, make all uppercase
				inputStr=inputStr.trim().toUpperCase();

				//  -- removes suffix
				if (inputStr.contains("N")) {
					inputStr=inputStr.replace("N", "");
				}
				if (inputStr.contains("S")) {
					inputStr=inputStr.replace("S", "");
				}
				if (inputStr.contains("E")) {
					inputStr=inputStr.replace("E", "");
				}
				if (inputStr.contains("W")) {
					inputStr=inputStr.replace("W", "");
				}
				if (inputStr.contains("-")) {
					inputStr=inputStr.replace("-", "");
				}

				//--Bring back the positive or negative for the final value
				if ((suffixSign=="-")||(preSign=="-")) {
					outDoubleLat=(-1)*Double.valueOf(inputStr);
				}else {
					outDoubleLat=Double.valueOf(inputStr);
				}

			} else {
				//TYPE1 - SIMPLE DOUBLE
				String suffixSign=suffixToSign(inputStr);
				if (suffixSign=="-") {
					outDoubleLat=(-1)*Double.valueOf(inputStr);
				}else {
					outDoubleLat=Double.valueOf(inputStr);
				}

			}
		}
		return outDoubleLat;
	}

	/*
	 * doublesToURL - takes input of two doubles, already cleaned and signed, and converts them into URL for google maps plotting
	 */
	public static String doublesToURL(double lat, double lon) {

				return "http://maps.google.com/?ie=UTF8&hq=&ll=" + roundDegs(lat,5) + ", " + roundDegs(lon,5);
	}
		
	/*
	 * roundSecs - formats the values to conform to requirements for google maps input
	 */
	public static String roundSecs(double value, int places) {
		double scale = Math.pow(10, places);
		if ((value<10) && (value>-0.0000000001)){
			return "0"+Double.toString(Math.round(value * scale) / scale);
		} else {
			if((value>-10) && (value<0)){
				return "-0"+Double.toString(Math.round((-1)*value * scale) / scale);
			}
		}
		return Double.toString(Math.round(value * scale) / scale);
	}

	/*
	 * roundDegs - formats the values to conform to requirements for google maps input
	 */
	public static String roundDegs(double value, int places) {
		double scale = Math.pow(10, places);
		if ((value<10) && (value>-0.0000000001)) {
			return "0"+Double.toString(Math.round(value * scale) / scale);
		}else {
			if((value>-10) && (value<0)){
				return "-0"+Double.toString(Math.round((-1)*value * scale) / scale);
			}
		}
		
		
		return Double.toString(Math.round(value * scale) / scale);
	}

	/*
	 * useString - method that examines a string coordinate and determines if it can be used for lat/lon plotting
	 *   USE1: can be evaluated to simple double value
	 *   USE2: can be evaluated to simple double with suffix of N E S W
	 *   USE3: can be evaluated to degrees minues seconds format with spaces separating each value, it may also include a suffix of N E S W
	 */
	public static boolean useString(String inputCoord) {
			if(!(coordType(inputCoord).equals("Not matched at all"))) {
				return true;
			} else {
				return false;
			}
	}
	
}
