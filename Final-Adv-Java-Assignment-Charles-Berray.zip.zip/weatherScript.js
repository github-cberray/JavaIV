

$.getJSON("https://api.openweathermap.org/data/2.5/weather?units=imperial&lat=34&lon=80&appid=dd30ad7ff3b47c3a712c4ba5dc46d485", function(data){
console.log(data);
});