var marker = null;
         var map = null;
         var markers = [];
         function initializeMap()
        {
            var map_canvas = document.getElementById('map_canvas');
            var map_options = {
                //center: myCenter,
                zoom: 15,
                mapTypeId: google.maps.MapTypeId.SATELLITE
            }
            map = new google.maps.Map(map_canvas, map_options)
		}
		
		function updateMap(gps)
    {
        var latitude = "${recentLocation.latitude}";
        var longitude = "${recentLocation.logitude}";
        var gpsPoint = new google.maps.LatLng(latitude, longitude);
        if(marker != null)
            marker.setMap(null);
        if(map!=null)
            map.setCenter(gpsPoint);
        marker = new google.maps.Marker({
        position:gpsPoint,
        map:map
        });
        markers.push(marker);
	}
	
	<div id="map_canvas"></div>