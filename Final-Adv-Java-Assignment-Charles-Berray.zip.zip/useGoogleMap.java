package com.fathomcurve.Lesson7;

import java.awt.Dimension;

import javax.swing.*;
import com.teamdev.jxbrowser.browser.Browser;
import com.teamdev.jxbrowser.engine.Engine;
import com.teamdev.jxbrowser.engine.EngineOptions;
import com.teamdev.jxbrowser.engine.RenderingMode;
import com.teamdev.jxbrowser.view.swing.BrowserView;


/**
 * useGoogleMap.java - this method initializes a googlemaps api and builds the url for inclusion in a Jpanel
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class useGoogleMap extends JPanel{

	public useGoogleMap(double latitude, double longitude) {

		// Initialize Chromium.
		Engine engine = Engine.newInstance(
				EngineOptions.newBuilder(RenderingMode.HARDWARE_ACCELERATED)
				.licenseKey("1BNDHFSC1G028J7GPM0A9DP9QXATQZXMGRPBB8362YTDYHA7P7YDOUTWZJ20M3HPIEYW6P")
				.build());
		Browser browser = engine.newBrowser();

		BuildCoordURL bcu = new BuildCoordURL();

		SwingUtilities.invokeLater(() -> {

			// Create and embed Swing BrowserView component to display web content.
			this.add(BrowserView.newInstance(browser));
			this.setSize(450, 450);

			//panel.setLocationRelativeTo(null);
			this.setVisible(true);

			// Load the required web page.
			browser.navigation().loadUrl(bcu.BuildCoordURL(latitude, longitude));

		});

	}
}
