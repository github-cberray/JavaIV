package com.fathomcurve.Lesson7;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineFactory;
import javax.script.ScriptEngineManager;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

/**
 * StartController.java - this class provides the connection point between the database and the model
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class StartController {

	public static void main(String[] args) {

		Logger.getLogger("org.mongodb.driver").setLevel(Level.WARNING);
		
		//CONNECTING
		
		System.out.println("Connecting to the MongoDB...");
		String connectionString = "mongodb+srv://MongoDbUser1:_YXF9gFW2nkwqsJ@cluster0.u12zz.mongodb.net/test?authSource=admin&replicaSet=atlas-t7q7ah-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";



		//WORKING WITH THE MONGO DB
		DBModel model = new DBModel();
		Logger mongoLogger = Logger.getLogger("org.mongodb.driver");
		mongoLogger.setLevel(Level.SEVERE);
		try (MongoClient mongoClient = MongoClients.create(connectionString)){
			MongoDatabase database = mongoClient.getDatabase("SPOTS");
			//MongoCollection <Document> collection = database.getCollection("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXAccount");
			MongoCollection <Document> locCollection = database.getCollection("Locs");
			model.setLocCollection(database.getCollection("Locs"));
			MongoCollection <Document> locNoteCollection = database.getCollection("LocNotes");
			model.setLocNoteCollection(database.getCollection("LocNotes"));
			MongoCollection <Document> userCollection = database.getCollection("Users");
			model.setUserCollection(database.getCollection("Users"));

		} catch (Exception e) {
			System.out.println("Updating values failed.");
		}

		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				//CREATE FRAME
				//StartView sv=new StartView("Fishing Location Manager", model);

				LoginView llv=new LoginView("Fishing Location Manager", model, null);
				//**************************************************************
				//PREPARE JAVASCRIPT FOR USE
//				//THIS PART SORT OF WORKS
//				ScriptEngineManager manager = new ScriptEngineManager();
//				ScriptEngine engine = manager.getEngineByName("nashorn");
//				//NOTE nashorn doesn't have reader input
//				for (ScriptEngineFactory factory : manager.getEngineFactories()) {
//					System.out.println(factory.getEngineName());
//				}
//				System.out.println("engine: "+ engine);
				
				//NOT SURE ABOUT THIS PART
//				StringReader reader = new StringReader();
//				// or 
//				Reader reader = new FileReader("index.js");
//				Object result = engine.eval(reader);				
//				engine.put("k",1134);
//				engine.eval("k+1");
//				StringWriter writer = new StringWriter();
//				engine.getContext().setWriter(new PrintWriter(writer,true));
//				
//				//to find out whether we can do concurrent scripts...
//				Object param = factory.getParameter("THREADING"); //returns null, MULTITHREADED, THREAD-ISOLATED, or STATELESS
				
				
				//****************************************************************
				//SET LAYOUT MANAGER WITH JAVA HERE
				llv.setLayout(new BorderLayout());
				llv.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				llv.setSize(1300,900);//width height

				llv.setVisible(true);

			}
		});
	}
}
