package com.fathomcurve.Lesson7;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * Webbrowser.java - this class allows for implementation of simple web browser within the app controls
 *
  * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 */
public class Webbrowser {

	private JFrame frame;
	private JPanel panel;
	private JEditorPane editor;
	private JScrollPane scroll;
	private JTextField field;
	private JButton button;
	private URL url;

	public Webbrowser(String title) {

		initComponents();
		frame.setTitle(title);
		//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800,600);
		frame.add(BorderLayout.NORTH, panel);
		panel.add(field);
		panel.add(button);
		frame.add(BorderLayout.CENTER,scroll);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

	}

	private void initComponents() {
		frame=new JFrame();
		panel=new JPanel();

		try {
			url=new URL("http://www.google.com");
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			editor = new JEditorPane(url);
			editor.setEditable(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		scroll=new JScrollPane(editor, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		field=new JTextField();
		SwingUtilities.invokeLater(new Runnable(){
			public void run() {
				field.setText(url.toString());
			}
		});

		button = new JButton("Go to URL");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					editor.setPage(field.getText());
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	}

	public static void main( String[] args ){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Webbrowser("My Web Browswer");
			}
		});
	}
	
}