package com.fathomcurve.Lesson7;

import java.awt.BorderLayout;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import org.bson.Document;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.teamdev.jxbrowser.browser.Browser;
import com.teamdev.jxbrowser.engine.Engine;

import jdk.internal.org.jline.reader.Parser;

/**
 * LocView.java - this class provides a view to see locations saved, to save and delete locations, as well as
 *   a place to launch to maps, weather, or notes on the locations
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class LocView extends JFrame{
	String lvTitle;
	public String getLvTitle() {		return lvTitle;	}
	public void setLvTitle(String lvTitle) {		this.lvTitle = lvTitle;	}

	public JTextField txtOwnerID;
	public JTextField txtLocName;
	public JTextField txtLatitude;
	public JTextField txtLongitude;
	public JList txtLocTag;
	public JTextField txtShareFriendID;
	
	
	public LocView(String title, DBModel model, JFrame oldFrame) {
		//System.out.println("Started the LocView. Old Frame is"+oldFrame.getTitle());
		BuildCoordURL bcu = new BuildCoordURL();
		
		this.setSize(900, 600);//width, height
		
		setLvTitle(title);
		super.setTitle(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

		//SET LAYOUTS
		
		JPanel panel1 = new JPanel();
		GroupLayout layout1 = new GroupLayout(panel1);
		layout1.setAutoCreateGaps(true);
		panel1.setSize(300, 150);

		JPanel panel2 = new JPanel();
		GroupLayout layout2 = new GroupLayout(panel2);
		layout2.setAutoCreateGaps(true);
		panel2.setSize(300, 100);
		
		JPanel panel3 = new JPanel();
		BoxLayout layout3 = new BoxLayout(panel3,1);
		//layout4.setAutoCreateGaps(true);
		panel3.setSize(300,100);

		JPanel panel4 = new JPanel();
		GroupLayout layout4 = new GroupLayout(panel4);
		layout4.setAutoCreateGaps(true);
		panel4.setSize(300,100);

		JPanel masterPanel = new JPanel();
		GridLayout masterLayout = new GridLayout(2,0);
		masterPanel.setLayout(masterLayout);
masterPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);


		//CREATE COMPONENTS

		JLabel lblLocName = new JLabel("Location Name");
		txtLocName = new JTextField(20);

		JLabel lblOwnerID = new JLabel("Owner ID");
		lblOwnerID.setVisible(false);
		txtOwnerID = new JTextField(20);
		txtOwnerID.setVisible(false);
		
		// -- Here we bring in the value of the theID, so later we can assign any new location to this id in the OwnerID field
		txtOwnerID.setText(model.getTheID());
		txtOwnerID.enableInputMethods(false);

		JLabel lblLatitude = new JLabel("Latitude");
		txtLatitude = new JTextField(12);
		String latTip=("You can enter a simple number and decimal, and it can have E or W at the end, you can also enter Degrees Minutes and Seconds separated by spaces");
		txtLatitude.setToolTipText("<html><p width=\"300\">" +latTip+"</p></html>");
		
		JLabel lblLongitude = new JLabel("Longitude");
		txtLongitude = new JTextField(12);
		String lonTip=("You can enter a simple number and decimal, and it can have E or W at the end, you can also enter Degrees Minutes and Seconds separated by spaces");
		txtLongitude.setToolTipText("<html><p width=\"300\">" +lonTip+"</p></html>");
		
		JLabel lblLocTag = new JLabel("Location Tags");
		String [] tagString = {"Poor", "ok", "Good", "Excellent","Bass","Bluegill","Crappie","Northern", "Catfish","Walleye"};
		String tagTip = "You can select more than one tag. These values will help with future searches for spots";
		lblLocTag.setToolTipText("<html><p width=\"300\">" +tagTip+"</p></html>");
		txtLocTag = new JList(tagString);
		txtLocTag.setFixedCellHeight(15);
		txtLocTag.setFixedCellWidth(55);
		txtLocTag.setVisibleRowCount(6);
		txtLocTag.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		add(new JScrollPane(txtLocTag));

		JLabel lblShareFriendID = new JLabel("ID of Friend to Share Location");
		lblShareFriendID.setVisible(false);
		txtShareFriendID = new JTextField(20);
		txtShareFriendID.setVisible(false);

		JButton btnCreate=new JButton("Create Location and Add Another");
		JButton btnShowMap = new JButton("Save then Show Map");
		JButton btnWeather = new JButton("Save then Show Weather");
JButton btnAccount = new JButton("Go to User Account View");
JButton btnNote = new JButton("Go to Location Notes");

		//TABLE OF LOCATIONS

		// -- get a two dim array of locations from mongo
		List <Document> locDocs = new ArrayList<Document>();
		JLabel tblHeader = new JLabel("Table of My Locations");
		String column[]= { "Location Name", "OwnerID", "Latitude", "Longitude"};

		// -- get the data from mongo, put the data into the table model
		String [][]data = model.readFromIDLocList(model.getTheID());
		
		
		
		
		DefaultTableModel jtModel = new DefaultTableModel(data, column);

		// -- build table
		JTable jt=new JTable(data,column);    
		jt.setBounds(30,40,400,200); 
		jt.setPreferredScrollableViewportSize(jt.getPreferredSize());
		jt.setFillsViewportHeight(true);

		// -- add table to scrollpane
		JScrollPane sp=new JScrollPane(jt); 
		sp.setMaximumSize(new Dimension(400, 200));//width, height

		// -- attach listener for rows
		jt.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		JButton btnRemoveRow = new JButton("Remove");

		
		//ADD COMPONENTS TO LAYOUT

		layout1.setHorizontalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblLocName)
						.addComponent(txtLocName))
						.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.CENTER)
						.addComponent(lblOwnerID)
						.addComponent(txtOwnerID))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(txtLocTag))
				);
		layout1.setVerticalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblLocName)
						.addComponent(txtLocTag))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.CENTER)
						.addComponent(txtLocName))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(lblOwnerID)
						.addComponent(txtOwnerID))
				);

		layout2.setHorizontalGroup(
				layout2.createSequentialGroup()
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblLatitude)
						.addComponent(lblLongitude)
						.addComponent(lblShareFriendID))
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(txtLatitude)
						.addComponent(txtLongitude)
						.addComponent(txtShareFriendID))
				);
		layout2.setVerticalGroup(
				layout2.createSequentialGroup()
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblLatitude)
						.addComponent(txtLatitude))
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(lblLongitude)
						.addComponent(txtLongitude)
						.addComponent(lblShareFriendID)
						.addComponent(txtShareFriendID))
				);

		panel3.add(btnCreate);
		panel3.add(btnRemoveRow);
		panel3.add(btnShowMap);
		panel3.add(btnWeather);
		panel3.add(btnAccount);
		panel3.add(btnNote);
		
		layout4.setHorizontalGroup(
				layout4.createSequentialGroup()
				.addGroup(layout4.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(tblHeader))
				.addGroup(layout4.createParallelGroup(GroupLayout.Alignment.CENTER)
						.addComponent(sp))
				);
		layout4.setVerticalGroup(
				layout4.createSequentialGroup()
				.addGroup(layout4.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(tblHeader))
				.addGroup(layout4.createParallelGroup(GroupLayout.Alignment.CENTER)
						.addComponent(sp))
				);

// -- Add panels into master panel
		
		masterPanel.add(panel1);
		//masterPanel.add(mapPanel);
		masterPanel.add(panel2);
		masterPanel.add(panel4);
		masterPanel.add(panel3);

		this.add(masterPanel);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		//this.pack();
		oldFrame.dispose();
		
		//ADD BEHAVIORS
		// -- CREATE LOCATION
		
		// -- check if text entered into fields is formatted adequate for plotting and entry
		
		txtLatitude.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) {
				validateLatEntry();			}
			@Override
			public void removeUpdate(DocumentEvent e) {
				validateLatEntry();			}
			@Override
			public void changedUpdate(DocumentEvent e) {}
		});

		txtLongitude.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) {
				validateLonEntry();			}
			@Override
			public void removeUpdate(DocumentEvent e) {
				validateLonEntry();			}
			@Override
			public void changedUpdate(DocumentEvent e) {}
		});
		
				
		// -- this is save then show map
		btnShowMap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ll){
				System.out.println("Getting lat/lon for ID: "+model.getTheID());

				String connectionString = "mongodb+srv://MongoDbUser1:_YXF9gFW2nkwqsJ@cluster0.u12zz.mongodb.net/test?authSource=admin&replicaSet=atlas-t7q7ah-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
				try (MongoClient mongoClient = MongoClients.create(connectionString)){
					MongoDatabase database = mongoClient.getDatabase("SPOTS");
					MongoCollection <Document> locCollection =database.getCollection("Locs");
					System.out.println("Connected to Locs");

					model.setLocName(txtLocName.getText());
					model.setLatitude(bcu.BuildCoordDBL(txtLatitude.getText()));
					model.setLongitude(bcu.BuildCoordDBL(txtLongitude.getText()));
					model.setLocTag(txtLocTag.getSelectedValuesList());
					model.setShareFriendID(txtShareFriendID.getText());
					
					//post values to database
					try {
						String locID = model.createLoc(locCollection, model.getLocName(), model.getTheID(),  model.getLatitude(), model.getLongitude(), model.getLocTag(),model.getShareFriendID());
						System.out.println(locID);
						model.setLocationID(locID);
						
						
					} catch (Exception e) {
						System.out.println("Create a location failed");
					}
					
					// create the coordinates in a google maps url
					MapView mv = new MapView("Location View", model, LocView.this);
					//useGoogleMap mapPanel = new useGoogleMap(model.getLatitude(), model.getLongitude());
					//mapPanel.setVisible(true);
					
				} catch (Exception e) {
					System.out.println("Updating values failed.");
				}

			}
		});
		
		btnNote.addActionListener(new ActionListener() {// GO TO LOCATION NOTES VIEW
			public void actionPerformed(ActionEvent ll){
				System.out.println("this is where we show the location notes and close this window");

				//save the location
				
				try {
					LocNoteView lnv= new LocNoteView("Location Notes View", model, LocView.this);
				} catch (Exception e) {
					System.out.println("Could not display the location notes view");
					//StartView sv=new StartView("Fishing Location Manager", model, LocView.this);
				}

			}
		});
		
		btnWeather.addActionListener(new ActionListener() {// SAVE LOCATION AND SHOW WEATHER
			public void actionPerformed(ActionEvent ll){
				System.out.println("this is where we show the weather and close this window");

				//save the location
				try {
					String locID = model.createLoc(model.getLocCollection(), model.getLocName(), model.getTheID(),  model.getLatitude(), model.getLongitude(), model.getLocTag(),model.getShareFriendID());
					System.out.println(locID);
					model.setLocationID(locID);
					

				} catch (Exception e) {
					System.out.println("Save a location failed");
				}

				try {
					WeatherView wv= new WeatherView("Weather View", model, "weather", LocView.this);
				} catch (MalformedURLException e) {
					System.out.println("Could not display the weather");
					//StartView sv=new StartView("Fishing Location Manager", model, LocView.this);
				}

			}
		});
		
		// -- this is save then add another
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ll){
				
				System.out.println("Fire off the creation of a location");
				//create database connection
				String connectionString = "mongodb+srv://MongoDbUser1:_YXF9gFW2nkwqsJ@cluster0.u12zz.mongodb.net/test?authSource=admin&replicaSet=atlas-t7q7ah-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
				try (MongoClient mongoClient = MongoClients.create(connectionString)){
					MongoDatabase database = mongoClient.getDatabase("SPOTS");
					MongoCollection <Document> locCollection =database.getCollection("Locs");
					//model.setLocCollection(database.getCollection("Locs"));
					System.out.println("Connected to Locs");
					//MongoCollection <Document> locNoteCollection = database.getCollection("LocNotes");

					model.setLocName(txtLocName.getText());
					model.setLatitude(bcu.BuildCoordDBL(txtLatitude.getText()));
					model.setLongitude(bcu.BuildCoordDBL(txtLongitude.getText()));
					model.setLocTag(txtLocTag.getSelectedValuesList());
					model.setShareFriendID(txtShareFriendID.getText());

					// -- change the view after creation
					btnCreate.setVisible(true);
					
					//post values to database
					try {
						String locID = model.createLoc(locCollection, model.getLocName(), model.getTheID(),  model.getLatitude(), model.getLongitude(), model.getLocTag(),model.getShareFriendID());
						System.out.println(locID);
						model.setLocationID(locID);
						
						// create the coordinates in a google maps url
						useGoogleMap mapPanel = new useGoogleMap(model.getLatitude(), model.getLongitude());
						mapPanel.setVisible(true);
						
					} catch (Exception e) {
						System.out.println("Mapping the location failed");
					}
					
					//Clear out the recently added values
					txtLatitude.setText("");
					txtLongitude.setText("");
					txtLocName.setText("");
					//lv.txtLocTag.set
					txtOwnerID.setText(model.getOwnerID());
					txtShareFriendID.setText("");

				} catch (Exception e) {
					System.out.println("Updating values failed.");
				}

			}
		});
		
		btnAccount.addActionListener(new ActionListener() {// RETURN TO ACCOUNT VIEW
			public void actionPerformed(ActionEvent ll){
				System.out.println("this is where we return to the main menu and close this window");
				//open the location view
				
				if (model.getUserFullName()==null) {
					StartView sv=new StartView("Fishing Location Manager", model, LocView.this);
				} else {
				StartView sv=new StartView("Fishing Location Manager (" + model.getUserFullName() + ")", model, LocView.this);
				}
				
			}
		});
		
		//remove button for the jtable of locations
	     btnRemoveRow.addActionListener(new ActionListener() {
	         @Override
	         public void actionPerformed(ActionEvent ae) {
	            // check for selected row first
	            if(jt.getSelectedRow() != -1) {
	               // remove selected row from the model
	            	jtModel.removeRow(jt.getSelectedRow());
	               JOptionPane.showMessageDialog(null, "Selected row scheduled for deletion at some point... hopefully successfully");
	            }
	            //sp.add(new JScrollPane(jt),BorderLayout.CENTER);
	         }
	      });
		
	}
	private void validateLatEntry() {
		//System.out.println("Checking coordinate for viable coordinate");
		BuildCoordURL bcu = new BuildCoordURL();
		if (bcu.useString(txtLatitude.getText())) {
			//we can use the text so far

		}else {
			//we cannot use the text, return the cursor to the field, highlight the text, and give user popup
			JOptionPane jop = new JOptionPane();
			JOptionPane.showMessageDialog(null,
					"You can enter a simple number and decimal, and it can have N or S at the end, you can also enter Degrees Minutes and Seconds separated by spaces",
					"Not valid as a coordinate",
					JOptionPane.ERROR_MESSAGE);

			txtLatitude.selectAll();
		}
	}
	private void validateLonEntry() {
		//System.out.println("Checking coordinate for viable coordinate");
		BuildCoordURL bcu = new BuildCoordURL();
		if (bcu.useString(txtLongitude.getText())) {
			//we can use the text so far

		}else {
			//we cannot use the text, return the cursor to the field, highlight the text, and give user popup
			JOptionPane jop = new JOptionPane();
			JOptionPane.showMessageDialog(null,
					"You can enter a simple number and decimal, and it can have E or W at the end, you can also enter Degrees Minutes and Seconds separated by spaces",
					"Not valid as a coordinate",
					JOptionPane.ERROR_MESSAGE);

			txtLatitude.selectAll();
		}
	}
}