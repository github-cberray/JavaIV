package com.fathomcurve.Lesson7;

import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.mongodb.client.MongoCollection;

/**
 * LoginView.java - this class provides a user login and password, giving access to the application, by checking against the user database in mongo
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class LoginView extends JFrame{

	String svTitle;
	public String getSvTitle() {		return svTitle;	}
	public void setSvTitle(String svTitle) {		this.svTitle = svTitle;	}

	public LoginView(String title, DBModel model, JFrame oldFrame) {

		setSvTitle(title);
		super.setTitle(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		this.setSize(400, 300);//width, height

		//SET LAYOUT MANAGER

		JPanel panel1 = new JPanel();
		GroupLayout layout1 = new GroupLayout(panel1);
		layout1.setAutoCreateGaps(true);
		panel1.setSize(300,200);

		JPanel panel2 = new JPanel();
		GroupLayout layout2 = new GroupLayout(panel2);
		layout2.setAutoCreateGaps(true);
		panel2.setSize(300,200);		


		JPanel masterPanel = new JPanel();
		GridLayout masterLayout = new GridLayout(2,0);
		masterPanel.setLayout(masterLayout);
		masterPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);

		//CREATE SWING COMPONENTS

		final JButton btnLoc = new JButton("Open Location View");
		final JButton btnLocNote = new JButton("Open Location Note View");
		//final JButton viewUser = new JButton("Create New User");
		JLabel lblUserName = new JLabel("UserName");
		JTextField txtUserName=new JTextField(25);
		JLabel lblUserPassword = new JLabel("Password");
		JPasswordField txtUserPassword = new JPasswordField(15);
		final JButton btnLogin = new JButton("Login");
		JButton btnReadFirst = new JButton("Read this First");
		JButton btnCreateUser = new JButton("Go to User Account Setup");
		JButton btnBugReport = new JButton("See the application bug report");

		//ADD SWING COMPONENTS TO CONTENT PANE

		layout1.setHorizontalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblUserName)
						.addComponent(lblUserPassword))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(txtUserName)
						.addComponent(txtUserPassword))
				);
		layout1.setVerticalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblUserName)
						.addComponent(txtUserName))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(lblUserPassword)
						.addComponent(txtUserPassword))
				);

		layout2.setHorizontalGroup(
				layout2.createSequentialGroup()
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(btnLoc)
						.addComponent(btnLogin)
						.addComponent(btnReadFirst)
						.addComponent(btnLocNote)
						.addComponent(btnCreateUser)
						.addComponent(btnBugReport))
				);
		layout2.setVerticalGroup(
				layout2.createSequentialGroup()
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.CENTER)
						.addComponent(btnLoc)
						.addComponent(btnLogin)
						.addComponent(btnReadFirst)
						.addComponent(btnBugReport))
				.addGroup(layout2.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(btnLocNote)
						.addComponent(btnCreateUser))
				);
		
		btnLocNote.setVisible(false);
		btnLoc.setVisible(false);
		btnLogin.setVisible(true);
		btnCreateUser.setVisible(false);
		masterPanel.add(panel1);
		masterPanel.add(panel2);
		this.add(masterPanel);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.pack();
		
		try {
			oldFrame.dispose();
		} catch (Exception e) {
			System.out.println("Initialized login view");
		}

		//ADD BEHAVIORS
		
		// -- LOGIN BUTTON
		btnLogin.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent ll){
				
				String replyID="hello";
				boolean successfulLogin=false;
				try {
					System.out.println("Trying to log in");
					//System.out.println("Username: "+txtUserName.getText()+" and password: "+ txtUserPassword.getText());
					replyID= model.checkPassword(model.userCollection, txtUserName.getText(), txtUserPassword.getText());
					successfulLogin=true;
					model.setTheID(replyID); // Register the user number for the session
					System.out.println("Validated that "+ txtUserName.getText()+" is valid with ID: "+model.getTheID());
					
				} catch (Exception e) {
					//Notify user unsuccessful
					System.out.println("Could not verify user at this time");
				}
				
				
				if (successfulLogin) {// IF LOGIN SUCCESSFUL
					
					btnLocNote.setVisible(true);
					btnLoc.setVisible(true);
					btnLogin.setVisible(false);
					lblUserName.setVisible(false);
					lblUserPassword.setVisible(false);
					txtUserPassword.setVisible(false);
					txtUserName.setVisible(false);
					
				} else {//LOGIN FAILED
					btnLogin.setVisible(true);
					btnCreateUser.setVisible(true);
					btnLocNote.setVisible(false);
					btnLoc.setVisible(false);
					lblUserName.setVisible(true);
					lblUserPassword.setVisible(true);
					txtUserPassword.setVisible(true);
					txtUserName.setVisible(true);
				}
				
			}
		});
		
		// -- LOCATION VIEW
		btnLoc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ll){
				
				//hide the panel and open the location view frame
				panel1.setVisible(false);
				panel1.remove(btnLoc);
				panel1.remove(btnLocNote);
				panel1.remove(btnLogin);

				//add a basic user home page type view to the panel1
				LocView lv = new LocView("Location View", model, LoginView.this);

			}
		});
		// -- LOCATION NOTE VIEW
		btnLocNote.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent nn){
				//btnLogin.setText("Performing action on location note view");
				//open the location note view
				panel1.setVisible(false);
				//panel1.remove(viewLoc);
				//panel1.remove(viewLocNote);
				panel1.remove(btnLogin);

				//add a basic user home page type view to the panel1
				LocNoteView lnv = new LocNoteView("Location Note View", model,LoginView.this);
				lnv.setBounds(20,20,1000,600);//horiz axis, vert axis, width, height 
				lnv.setVisible(true);

			}
		});

		btnReadFirst.addActionListener(new ActionListener() {// GO TO READ ME
			public void actionPerformed(ActionEvent ll){
				System.out.println("this is where we return to the main menu and close this window");
				//open the location view

				if (model.getUserFullName()==null) {
					try {
						WeatherView wv= new WeatherView("Weather View", model, "readfirst", LoginView.this);
					} catch (MalformedURLException e) {
						System.out.println("Could not display the readme information");
						StartView sv=new StartView("Fishing Location Manager", model, LoginView.this);
					}
				}
			}
		});
		
		
		btnBugReport.addActionListener(new ActionListener() {// GO TO READ ME
			public void actionPerformed(ActionEvent ll){
				System.out.println("this is where we return to the main menu and close this window");
				//open the location view

				if (model.getUserFullName()==null) {
					try {
						WeatherView wv= new WeatherView("Weather View", model, "bugreport", LoginView.this);
					} catch (MalformedURLException e) {
						System.out.println("Could not display the bug report information");
						StartView sv=new StartView("Fishing Location Manager", model, LoginView.this);
					}
				}
			}
		});
		
		// -- USER VIEW
		btnCreateUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent uu){
				//open the user view
				UserView uv = new UserView(model, title, LoginView.this);

				uv.setBounds(20,20,1200,1000);//horiz axis, vert axis, width, height 
				uv.setVisible(true);
				uv.pack();

			}
		});
		
	}
}