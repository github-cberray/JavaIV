package com.fathomcurve.Lesson7;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * StartView.java - this class provides a view of the user setup, allowing for creation of a new user
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class StartView  extends JFrame{
	String svTitle;

	public String getSvTitle() {		return svTitle;	}
	public void setSvTitle(String svTitle) {		this.svTitle = svTitle;	}

	public StartView(String title, DBModel model, JFrame oldFrame) {

		setSvTitle(title);
		super.setTitle(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  


		//SET LAYOUT MANAGER
		Container panel1 = this.getContentPane();
		GroupLayout layout1 = new GroupLayout(panel1);
		layout1.setAutoCreateGaps(true);
		layout1.setAutoCreateContainerGaps(true);
		panel1.setLayout(layout1);

		//CREATE SWING COMPONENTS

		final JButton viewLoc = new JButton("Open Location View");
		final JButton viewLocNote = new JButton("Open Location Note View");
		final JButton viewUser = new JButton("Edit User");

		JLabel lblUserName = new JLabel("UserName");
		JTextField txtUserName=new JTextField(20);
		//JLabel lblUserPassword = new JLabel("Password");
		//final JButton btnLogin = new JButton("Login");

		//ADD SWING COMPONENTS TO CONTENT PANE

		layout1.setHorizontalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(viewLoc)
						.addComponent(viewLocNote))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(viewUser))
				);
		layout1.setVerticalGroup(
				layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(viewLoc)
						.addComponent(viewUser))
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(viewLocNote))
				);

		this.pack();
		this.setLocationRelativeTo(null);
		this.setVisible(true);
oldFrame.dispose();


		//ADD BEHAVIOR
		
		// -- LOCATION VIEW
		viewLoc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ll){
				
				//hide the panel and open the location view frame
				panel1.setVisible(false);
				panel1.remove(viewLoc);
				panel1.remove(viewLocNote);
				panel1.remove(viewUser);
				

				//add a basic user home page type view to the panel1
				LocView lv = new LocView("Location View", model, StartView.this);

			}
		});
		
		// -- LOCATION NOTE VIEW
		viewLocNote.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent nn){
				//open the location note view
				panel1.setVisible(false);
				panel1.remove(viewUser);

				//add a basic user home page type view to the panel1
				LocNoteView lnv = new LocNoteView("Location Note View", model,StartView.this);
				lnv.setBounds(20,20,600,600);//horiz axis, vert axis, width, height 
				lnv.setVisible(true);

			}
		});
		
		// -- USER VIEW
		viewUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent uu){
				//open the user view
				UserView uv = new UserView(model, title, StartView.this);

				uv.setBounds(20,20,1200,1000);//horiz axis, vert axis, width, height 
				uv.setVisible(true);
				uv.pack();

			}
		});
	}

}
