package com.fathomcurve.Lesson7;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

/**
 * LocNoteView - class provides view of location notes along with buttons to connect to other frames
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 8.28.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *
 */
public class LocNoteView extends JFrame{
	String lnvTitle;
	public String getLnvTitle() {		return lnvTitle;	}
	public void setLnvTitle(String lnvTitle) {		this.lnvTitle = lnvTitle;	}

	public LocNoteView(String title, DBModel model, JFrame oldFrame) {
		BuildCoordURL bcu = new BuildCoordURL();
		
		this.setSize(1000, 400);//width, height
		setLnvTitle(title);
		super.setTitle(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

		//SET LAYOUT

		JPanel panel1 = new JPanel();
		GroupLayout layout1 = new GroupLayout(panel1);
		layout1.setAutoCreateGaps(true);
		layout1.setAutoCreateContainerGaps(true);
		panel1.setSize(300, 100);

		JPanel panel2 = new JPanel();
		GroupLayout layout2 = new GroupLayout(panel2);
		layout2.setAutoCreateGaps(true);
		layout2.setAutoCreateContainerGaps(true);
		panel2.setSize(300, 100);

		JPanel panel3 = new JPanel();
		GroupLayout layout3 = new GroupLayout(panel3);
		layout3.setAutoCreateGaps(true);
		layout3.setAutoCreateContainerGaps(true);
		panel3.setSize(300, 100);
		
		JPanel panel4 = new JPanel();
		GroupLayout layout4 = new GroupLayout(panel4);
		layout4.setAutoCreateGaps(true);
		layout4.setAutoCreateContainerGaps(true);
		panel4.setSize(300, 100);

		JPanel masterPanel = new JPanel();
		GridLayout layoutMaster = new GridLayout(0,2);
		masterPanel.setLayout(layoutMaster);
		masterPanel.setSize(1000, 600);

		JPanel totalPanel = new JPanel();
		GroupLayout layoutTotal = new GroupLayout(totalPanel);
		
		JPanel tablePanel = new JPanel();
		GroupLayout layoutTable = new GroupLayout(tablePanel);
		tablePanel.setSize(300, 100);
		
		//ADD COMPONENTS

		//JLabel lblLocNoteID = new JLabel("Location Note ID");
		//JTextField txtLocNoteID = new JTextField(20);
		//txtLocNoteID.setEditable(false);

		JLabel lblLocID = new JLabel("Location ID");
		JTextField txtLocID = new JTextField(20);
		txtLocID.setEditable(false);

		//JLabel lblNoteDate = new JLabel("Note Entry Date");
		JTextField txtNoteDate = new JTextField(20);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
		   txtNoteDate.setText(dtf.format(now)); 
		

		JLabel lblNote = new JLabel("Location Note");
		JTextField txtNote = new JTextField(15);

		JLabel lblShareNoteTF = new JLabel("Share This Note?");
		JCheckBox ckShareNoteTF = new JCheckBox();

		JButton btnCreate=new JButton("Create New Note");
		//JButton btnUpdate=new JButton("Update Note");
		//JButton btnDelete=new JButton("Delete This Note");
		JButton btnLoc = new JButton("Go to My Locations");
		

		//TABLE OF LOCATION NOTES

		// -- get a two dim array of locations from mongo
		List <Document> locDocs = new ArrayList<Document>();
		JLabel tblHeader = new JLabel("Table of My Location Notes");
		String column[]= { "UserID", "AnotherID", "Location ID", "Note Date", "Note", "Share"};

		// -- get the data from mongo, put the data into the table model
		String [][]data = model.readFromIDNoteList(model.getTheID());


		DefaultTableModel jtModel = new DefaultTableModel(data, column);

		// -- build table
		JTable locNoteTable=new JTable(data,column);    
		locNoteTable.setBounds(30,40,400,200); 
		locNoteTable.setPreferredScrollableViewportSize(locNoteTable.getPreferredSize());
		locNoteTable.setFillsViewportHeight(true);

		// -- add table to scrollpane
		JScrollPane tablePane=new JScrollPane(locNoteTable); 
		tablePane.setMaximumSize(new Dimension(400, 200));//width, height

		// -- attach listener for rows
		locNoteTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		JButton btnRemoveRow = new JButton("Remove Note");




		//ADD COMPONENTS TO LAYOUT

		layout1.setHorizontalGroup(layout1.createSequentialGroup()
				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblLocID)
						.addComponent(txtLocID))
				);
		layout1.setVerticalGroup(layout1.createSequentialGroup()

				.addGroup(layout1.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(lblLocID)
						.addComponent(txtLocID))
				);

		layout2.setHorizontalGroup(layout2.createSequentialGroup()
				.addComponent(txtNoteDate)
				.addComponent(lblNote)
				.addComponent(txtNote)
				);
		layout2.setVerticalGroup(layout2.createSequentialGroup()
				//.addComponent(lblNoteDate)
				.addComponent(txtNoteDate)
				.addComponent(lblNote)
				.addComponent(txtNote)
				);

		layout3.setHorizontalGroup(layout3.createSequentialGroup()
				.addGroup(layout3.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(lblShareNoteTF))
				.addGroup(layout3.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(ckShareNoteTF))
				);
		layout3.setVerticalGroup(layout3.createSequentialGroup()
						.addComponent(lblShareNoteTF)
						.addComponent(ckShareNoteTF)
				);

		layout4.setHorizontalGroup(layout4.createSequentialGroup()
						.addComponent(btnCreate)
						.addComponent(btnRemoveRow)
						.addComponent(btnLoc)
				);
		layout4.setVerticalGroup(layout4.createSequentialGroup()
				.addGroup(layout4.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(btnCreate)
						.addComponent(btnLoc)
						.addComponent(btnRemoveRow))
				);

		layoutTable.setHorizontalGroup(layoutTable.createSequentialGroup()
						.addComponent(tablePane)
				);
		layoutTable.setVerticalGroup(layoutTable.createSequentialGroup()
						.addComponent(tablePane)
				);
		
		layoutTotal.setHorizontalGroup(layoutTotal.createSequentialGroup()
				.addComponent(masterPanel)
				.addComponent(tablePanel)
		);
		layoutTotal.setVerticalGroup(layoutTotal.createSequentialGroup()

				.addGroup(layoutTotal.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(masterPanel)
						.addComponent(tablePanel))
				);
		// -- Add panels into master panel and to the frame
		
		masterPanel.add(panel1);
		masterPanel.add(panel2);
		masterPanel.add(panel3);
		masterPanel.add(panel4);

		totalPanel.add(masterPanel);
		totalPanel.add(tablePanel);
		
		this.add(totalPanel);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		//this.pack();
		oldFrame.dispose();

		// ADD BEHAVIORS
		
		//-- Create a location
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ll){
				System.out.println("Fire off the creation of a location note");
				//update the location note view
				String connectionString = "mongodb+srv://MongoDbUser1:_YXF9gFW2nkwqsJ@cluster0.u12zz.mongodb.net/test?authSource=admin&replicaSet=atlas-t7q7ah-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
				try (MongoClient mongoClient = MongoClients.create(connectionString)){
					MongoDatabase database = mongoClient.getDatabase("SPOTS");

					MongoCollection <Document> locNoteCollection =database.getCollection("LocNotes");
					System.out.println("Connected to Location Notes");

					//store values in the model
					model.setNoteDate(txtNoteDate.getText());
					model.setNote(txtNote.getText());
					model.setLocationID(txtLocID.getText());
					model.setShareNoteTF(ckShareNoteTF.isSelected());

					//store values in the database
					if (model.createLocNote(locNoteCollection, model.getLocationID(), model.getNoteDate(), model.getNote(), model.isShareNoteTF())) {
						System.out.println("Location note created");
						//clear values from fields
					txtNoteDate.setText("");
					txtNote.setText("");
					}
				} catch (Exception e) {
					String msg = "Could not save that location, please re-check your information";
					String boxTitle = "NOT saved";
					JOptionPane jop = new JOptionPane();
					JOptionPane.showMessageDialog(null,	msg,boxTitle,JOptionPane.ERROR_MESSAGE);
				}

			}
		});
		//-- remove button for the jtable of locations
		btnRemoveRow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				// check for selected row first
				if(locNoteTable.getSelectedRow() != -1) {
					// remove selected row from the model
					jtModel.removeRow(locNoteTable.getSelectedRow());
					JOptionPane.showMessageDialog(null, "Selected note scheduled for deletion at some point... hopefully successfully");
				}
				//sp.add(new JScrollPane(jt),BorderLayout.CENTER);
			}
		});
		//-- go to the LOCATION view
		btnLoc.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				// check for selected row first
				LocView lv = new LocView("Location View", model, LocNoteView.this);
			}
		});
	}
}
