package assignment4;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/*
 * Lesson4SAXHandler.java - this program uses methods to identify the needed elements and parse them to
 *  the console in the correct format
 *  
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 7.20.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 */
public class Lesson4SAXHandler extends DefaultHandler{
    //instance of the ArrayList to use in parsing
	static ArrayList<String> theParse = new ArrayList<String>();

	//startDocument - method to manage start of document output to console
	public void startDocument() throws SAXException{
		theParse.add("Results of XML Parsing using SAX Parser:"+"\n");
	}

	//endDocument - method to filter out unneeded tags from end of the document
	public void endDocument() throws SAXException{
		for (int i=0;i<theParse.size();i++) {
			if((theParse.get(i).trim()=="")||(theParse.get(i).length()<3)||(theParse.get(i).contains("1538752262"))) {
				//do nothing
			}else {
				System.out.print(theParse.get(i));
			}
		}

	}

	//startElement - method that takes the element infomation and parses localNames from the XML
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException{

		switch (localName.trim()) {
		case "jobresult":
			break;
		case "data":
			break;
		case "structure":
			break;
		case "double-long-unsigned":
			break;
		default:
			theParse.add(localName+": ");
			break;
		}
	}
	
	//characters - method that takes char array, start and length values as parameters, then parses 
	//  values from the text of the tag values
	public void characters(char ch[], int start, int length) throws SAXException {
		theParse.add(new String(ch, start, length).trim()+"\n");
	}

	//endElement - method to manage the end element
	public void endElement(String uri, String localName, String qName) throws SAXException{
	}
	
}
