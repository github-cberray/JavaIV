package assignment4;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import org.xml.sax.SAXException;

/*
 * Lesson4XML.java - this program parses an XML file by three methods, DOM, SAX, and XPath
 *  returning formatted string results to the console
 * 
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 7.20.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *  
 */
public class Lesson4XML {

	public static void main(String[] args) throws IOException, XMLStreamException, 
	TransformerException, SAXException, ParserConfigurationException, XPathExpressionException {

		// Identify the file to retrieve
		final String filename= "JobResult_UCSDExt.xml";

		// Run DOM Parser to obtain output
		Lesson4DOMParser dp = new Lesson4DOMParser();
		dp.DOMParser(filename);
		
		// Run SAX Parser to obtain output
		Lesson4SAXParser lsp = new Lesson4SAXParser();
		lsp.SAXPrint(filename);
		
		// Run XPath to Parse output
		Lesson4XPath lxp = new Lesson4XPath();
		lxp.xPathParse(filename);
		
		System.out.println("All Done!");
	}
	
}



