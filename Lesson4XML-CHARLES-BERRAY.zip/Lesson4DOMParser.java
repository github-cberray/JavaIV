package assignment4;

import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/*
 * Lesson4DOMParser.java - this program takes an XML file then uses DOM Parser to parse select values
 * and print them to console.
 * 
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 7.20.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 */
public class Lesson4DOMParser {

	public void DOMParser(String filename) throws SAXException, IOException, ParserConfigurationException {
		System.out.println("Results of XML Parsing using DOM Parser:");
		
		//Create instance of factory, builder, and doc to allow parsing
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(filename);
        doc.getDocumentElement().normalize();
        
        //serial 
        System.out.println("serial: "+doc.getElementsByTagName("serial").item(0).getTextContent());
        //visible string
        System.out.println("visible-string: "+doc.getElementsByTagName("visible-string").item(0).getTextContent());
        //unsigned
        System.out.println("unsigned: "+doc.getElementsByTagName("unsigned").item(0).getTextContent());
	}
	
}