package assignment4;

// This package consists of multiple files to complete the operation of
   // parsing the XML file to the console in three different ways.

// Lesson4XML.java - this is the main file, it makes use of each of the
   // separate java files to conduct the parsing

// Lesson4DOMParser.java - DOM Parsing

// Lesson4SAXParser.java - SAX Parsing, uses a handler file to assist parsing
// Lesson4SAXHandler.java - assists in the parsing of the SAX information from the XML file

// Lesson4XPath.java - XPath Parsing