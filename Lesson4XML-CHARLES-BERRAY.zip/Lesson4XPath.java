package assignment4;

import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


/*
 * Lesson4XPath.java - this program makes use of XPath to parse an XML file to the console
 *  
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 7.20.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 */
public class Lesson4XPath {


	public void xPathParse(String filename) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder=factory.newDocumentBuilder();
		Document doc=builder.parse(filename);

		//Create an instance of the XPathFactory
		XPathFactory xpFactory = XPathFactory.newInstance();
		XPath path=xpFactory.newXPath();
		System.out.println("Results of XML Parsing using XPath:");
		
		//Parse out the serial information
		XPathExpression exprSerial = path.compile("//serial/text()");
		NodeList nodes = (NodeList)exprSerial.evaluate(doc, XPathConstants.NODESET);
		System.out.println("serial: "+nodes.item(0).getNodeValue());	
		
		//Parse out the visible string information
		XPathExpression exprVisString = path.compile("//data/visible-string/text()");
		nodes = (NodeList)exprVisString.evaluate(doc, XPathConstants.NODESET);
		System.out.println("visible-string: "+nodes.item(0).getNodeValue());
		
		//Parse out the unsigned information
		XPathExpression exprUnsigned = path.compile("//data/structure/unsigned/text()");
		nodes = (NodeList)exprUnsigned.evaluate(doc, XPathConstants.NODESET);
		System.out.println("unsigned: "+nodes.item(0).getNodeValue());

	}
	
}
