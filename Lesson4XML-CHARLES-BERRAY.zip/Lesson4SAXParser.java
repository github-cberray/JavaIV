package assignment4;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/*
 * Lesson4SAXParser.java - this program uses a method that receives a filename, then
 *  parses it, using handler to resolve the required output to the console
 *  
 * @author Charles S Berray, cberray@gmail.com
 * @version 1.0 7.20.2021
 * 
 * for class: 157160 Java Programming IV Advanced Java Programming
 * for Professor: Norman McEntire, norman.mcentire@gmail.com
 *  
 */
public class Lesson4SAXParser {
	
	public void SAXPrint(String filename) throws SAXException, IOException, ParserConfigurationException {

		// Construct the handler
		DefaultHandler handler = new Lesson4SAXHandler();

		//Create an instance of the SAX Parser Factory
		SAXParserFactory factory = SAXParserFactory.newInstance();
		factory.setNamespaceAware(true);

		try {
			//Create an instance of the SAXParser
			SAXParser saxParser = factory.newSAXParser();
			//Parse the file, using the handler to manage the output
			saxParser.parse(filename, handler);
		} catch (ParserConfigurationException e) {		e.printStackTrace();
		} catch (SAXException e) {			e.printStackTrace();
		} catch (IOException e) {			e.printStackTrace();
		}


	}
}